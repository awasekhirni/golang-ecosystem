package main

import (
	"net/http"

	"github.com/go-chi/chi"
	"github.com/go-chi/chi/middleware"
)

func main() {
	app := chi.NewRouter()
	app.Use(middleware.Logger)
	app.Use(middleware.Recoverer)

	app.Get("/greet", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Welcome to Sycliq.com! We are running chi-golang framework!"))
	})

	//rendering the server
	http.ListenAndServe(":9393", app)
}
