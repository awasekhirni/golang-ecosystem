package main

import (
	"net/http"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"

)

func main(){
	//creating an echo instance 

	server:=echo.New()

	//Middleware 
	server.Use(middleware.Logger(),middleware.Recover())

	server.GET("/api/greet", greetThem )

	//kickstart the server 
	server.Logger.Fatal(server.Start(":9393"))
}

func greetThem(ctx echo.Context) error{
	return ctx.String(http.StatusOK, "Welcome to SYCLIQ-GEOSPATIAL/TPRI- ALPHAFACTORY CODE PLAY SESSIONS")
}