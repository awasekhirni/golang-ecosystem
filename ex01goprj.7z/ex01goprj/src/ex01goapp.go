// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
//go package declaration
package main
//importing go packages
import (
	"fmt"
)
//variable declrations with types in Go
var (
  msg string ="i grew up watching he-man, duck tales"
)
// init function is called before the main function.
func init(){
	msg="my kids are growing up watching full house and stranger things"
}
// main function is starting point of the application
func main() {
	fmt.Println(msg)
}