package main
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
import (
	"fmt"
)

var (
	youArehappy bool=true
)

func main(){
	fmt.Println("Go Programming construct demo: control statements and looping")
	

	if youArehappy ==true{
		fmt.Println("If you are happy and you know then clap your hands!")
	}else{
		fmt.Println("I am not happy!, i stomp my feet!!")
	}
	
	myscore:=5
	switch {
	case myscore== 1:
		fmt.Println("I started off just now in Founder Institute")
	case myscore==2:
		fmt.Println("My pitch statement has improved")
	case myscore==3:
		fmt.Println("You are getting there!")
	case myscore==4:
		fmt.Println("You are pitch is not there yet!")
	case myscore==5:
		fmt.Println("You have nailed it!, Perfect pitch")
	}

	//loopy loop for loop
	for i:=0; i<5; i++{
		println(i)
	}
	//infinite loop with a break statement
	k:=0
	for {
		k++
		println(k)
		if k>3{
			break
		}
	}

	//slicing an array 
	basketItems:=[]string{"milk","eggs","beer","diapers","maplesyrup","carrots"}

	for idx, item:=range basketItems{
		fmt.Println(idx,item)
	}

	//iterating through a map 
	movies:=make(map[string]string)
	movies["first"]="pk"
	movies["second"]="munnabhai"
	movies["third"]="croods"

	for n,movie:=range movies{
		fmt.Println(n,movie)
	}


}