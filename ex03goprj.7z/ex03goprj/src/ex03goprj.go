// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
package main 
import "fmt"
func main(){
	pkGenre:=[]string{"aamir khan","ranveer kapoor","x","y","z"}
	weeklyEarnings:=[]float64{12632.832,2187236.23,3278238.128,3648372.27,47392812.23,4317821.23,526171271.127}
	fmt.Println("0-Select your movie choice, you want to watch")
	fmt.Println("1-PK")
	fmt.Println("2-the croods")
	var option string 
	fmt.Scanln(&option)
	switch option{
	case "1":
		for idx,actor:=range pkGenre{
			fmt.Printf("the movie actors are %d in order:%s\n",idx,actor)
		}
	
	case "2":
		for idx,e:=range weeklyEarnings{
			fmt.Printf("the weekly earnings are %d by the day of the week are:%.00f\n",idx,e)
		}
	
	default:
		fmt.Println("You have selected no option")
	}
}