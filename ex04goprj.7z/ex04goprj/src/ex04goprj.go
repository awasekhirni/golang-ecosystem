package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
import (
	"fmt"
)

func main(){
  greetOwner()
  caller:="Joey"
  msg:="Jesse plays good imitation of elvis presley!"
  whoisCalling(caller)
  fmt.Println(caller)
  msgReceived(&msg)
  fmt.Println(msg)

  mailBox("gmailMsg","yahooMsg","outlookMsg","rocketMsg")

  gamescore:=sumMeup(12,23,32,43)
  fmt.Println(gamescore)

  itemInArray,cricscore:=summation(62,36,36,27,27)
  fmt.Println(itemInArray,cricscore)

  //annonymous function definition
  multiAnn:= func(vals ...int) (noVals int, mulResult int){
	  for _, val :=range vals{
		  mulResult +=val
	  }
	  noVals = len(vals)
	  return noVals,mulResult
  }

  println("annonymous function demo")
  g, gMul:=multiAnn(12,13,14,15,16,17)
  println("multiplication:",g,gMul)

}
//functions in go
func greetOwner(){
	fmt.Println("Welcome to Go Programming: Syed Awase!")
}

//functions with input arguments
func whoisCalling(caller string){
	fmt.Println("Hello!, This is Syed, May i know who's calling?"+caller)
	caller="Jesse"
}

func msgReceived(msg *string){
	fmt.Println(*msg)
	*msg="Joey Gladstone is best imitator of popeye the sailor man!"

}

//variadic function 
func mailBox(mailMsg ...string){
	for _, mailMsg :=range mailMsg{
		fmt.Println(mailMsg)
	}
}
//variadic function with return type 
func sumMeup(mynos ...int) int {
	myresult:=0
	for _,no:=range mynos{
		myresult+=no 
	}
	return myresult
}

// multiple return types
func summation(otherNos ...int) (int,int){
	myresult:=0
	for _, n:= range otherNos{
		myresult+=n
	}
	return len(otherNos),myresult
}
