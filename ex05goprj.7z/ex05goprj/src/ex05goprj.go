package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
import ("fmt")

//custom type 
type myStruct struct{
	myfield1 string 
}

type employee struct{
	empId int 
	empName string
	empIsactive bool 

}

func main(){
	myInstance := myStruct{}
	//assigning values to the variable
	myInstance.myfield1="Syed Awase Khirni"
	println(myInstance.myfield1)

	aicy := new(employee)
	aicy.empId=32187
	aicy.empName="Syed Awase Khirni"
	aicy.empIsactive=true
	println(aicy)
	fmt.Println(aicy)
	println(aicy.empId)
	println(aicy.empName)

	sak:=&employee{13267,"Syed Ameese Sadath",true}
	fmt.Println(sak)


	fountainHead:=newProduct()
	fountainHead.myMap["fh"]="Ayn Rand"
	fmt.Println(fountainHead)
}


type product struct{
	myMap map[string]string 
}

//constructor function 
func newProduct() *product{
	result:= product{}
	result.myMap = map[string]string{}
	return &result //reference to instance
}