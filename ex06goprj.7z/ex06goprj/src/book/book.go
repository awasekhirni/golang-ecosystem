package book 
// book struct

type Book struct{
	pages int
	author string 
	price int 
	language string 
}

//constructor function 
func CreateBook(pages int, author string, price int, language string) *Book{
	return &Book{
		pages:pages,
		author:author,
		price:price,
		language:language,
	}
}

//get book
func (b Book) Pages() int{
	return b.pages
}

//set book
func (b *Book) SetPages(pages int){
	b.pages=pages
}


//get author 
func (b Book) Author() string{
	return b.author
}

//set author 
func (b *Book) SetAuthor(author string){
	b.author = author
}

//get price
func (b Book) Price() int{
	return b.price
}

//set price 
func (b *Book) SetPrice(price int){
	b.price=price
}




func (b Book) Language() string{
	return b.language
}


func (b *Book) SetLanguage(language string){
	b.language=language
}