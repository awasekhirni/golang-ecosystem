package employee
import "fmt"

type Employee struct{
	firstName string 
	lastName string 
	totalLeaves int
	leavesTaken int 
	salary int 
	bankAccount string 
}

//constructor 
//uppercase:public 
//lowercase:private

func CreateEmployee(firstName string, lastName string, totalLeaves int, leavesTaken int,  salary int, bankAccount string) *Employee{
	return &Employee{
		firstName:firstName,
		lastName:lastName,
		totalLeaves:totalLeaves,
		leavesTaken:leavesTaken,
		salary:salary,
		bankAccount:bankAccount,
	}
}

//getter and setter methods
func (e Employee) LeavesRemaining() {
	fmt.Printf("%s %s has %d leaves remaining", e.firstName, e.lastName, (e.totalLeaves - e.leavesTaken))
}
