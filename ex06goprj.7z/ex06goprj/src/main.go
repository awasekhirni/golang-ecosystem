package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com/www.sycliq.com
import (
	"fmt"
	"./book"
	"./employee"
)

func main(){
	fh:=book.CreateBook(800,"Ayn Rand",25,"english")
	//calling methods 
	fh.SetPages(875)
	fmt.Printf("No of pages in the book are: %v\n", fh.Pages())
	fmt.Println(fh.Author())
	fmt.Println(fh.Price())
	fmt.Println(fh.Language())


	//employe instance
	emp := employee.CreateEmployee(
		 "Awase",
		 "Syed",
		40,
		18,
		 240000,
		"5326628000157186")

   emp.LeavesRemaining()

}