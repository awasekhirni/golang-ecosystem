package customer 

import "fmt"

type Customer struct{
	Name string 
	Address Address
}


type Address struct{
	Number string 
	Street string 
	City string 
	State string 
	Zip string
}


//method 
func (c *Customer) Talk(){
	fmt.Println("Helo,my name is: ", c.Name)
}

func (c *Customer) Location(){
	fmt.Println("I’m at", c.Address.Number, c.Address.Street, c.Address.City, c.Address.State, c.Address.Zip)
}


