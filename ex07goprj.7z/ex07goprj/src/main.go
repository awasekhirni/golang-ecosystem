// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com 
package main 

import (
	"./customer"
)

func main(){
	c:= customer.Customer{
        Name: "Syed Awase Khirni",
        Address: customer.Address{
            Number: "227",
            Street: "5 A Main",
            City:   "Bangalore",
            State:  "Karnataka",
            Zip:    "560043",
        },
    }

    c.Talk()
    c.Location()
}