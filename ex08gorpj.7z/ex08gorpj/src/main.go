package main

import (
	"fmt"
	"./payment")

func main(){
	credit := payment.CreateCreditAccount(
		"Syed Awase",
		"6666-7777-8888-0101-9999",
		5,
		2025,
		678)

	fmt.Printf("Owner name: %v\n", credit.OwnerName())
	fmt.Printf("Card number:%v\n", credit.CardNumber())
	fmt.Printf("Trying to change card number")
	err := credit.SetCardNumber("invalid")
	if err != nil {
		fmt.Printf("That didn't work:%v\n", err)

	}
	fmt.Printf("Available credit:%v\n", credit.AvailableCredit())

}