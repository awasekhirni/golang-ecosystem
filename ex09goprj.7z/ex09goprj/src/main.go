package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import (
	"fmt"
	"./runes"
)


func main(){
	var myname runes.MyString 
	myname = runes.MyString("Syed Awase Khirni")
	var v runes.VowelsFinder
	v=myname 
	fmt.Printf("Vowels are %c", v.FindVowels())

}