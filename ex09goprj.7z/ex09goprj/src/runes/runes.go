package runes 

type MyString string 

//interface definition 
type VowelsFinder interface{
	FindVowels() []rune
}


/*interface method implementation*/
func (ms MyString) FindVowels() []rune{
	var vowels [] rune
	for _, rune := range ms {
        if rune == 'a' || rune == 'e' || rune == 'i' || rune == 'o' || rune == 'u' {
            vowels = append(vowels, rune)
        }
    }
    return vowels
}	
