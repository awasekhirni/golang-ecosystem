package main 

import (
	"net/http"
	"log"
	"./router"
	"fmt"
)


func main(){
	fmt.Println("RethinkGoLang Application on port 3000")
	log.Fatal(http.ListenAndServe(":3000",router.Router()))
}