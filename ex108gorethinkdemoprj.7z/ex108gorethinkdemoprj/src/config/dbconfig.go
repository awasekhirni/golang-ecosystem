package config 

//update the go rethink db version prior to pushing to github
import (
	"log"
	rethinkdb "gopkg.in/dancannon/gorethink.v6"
)

func GetSession() *rethinkdb.Session{
	session, err:=rethinkdb.Connect(rethinkdb.ConnectOpts{
		Address:"localhost:28015",
		Database:"ex108goprjdb",
	})

	if err!=nil{
		log.Fatalln(err.Error())
	}

	return session
}