package controllers 

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"../models"
	"../utils"
	"github.com/julienschmidt/httprouter"
	rethinkdb "gopkg.in/dancannon/gorethink.v6"
)

const(
	xml="xml"
)

type(
	DbConnSession struct{
		session *rethinkdb.Session
	}
)

func AppSession(s *rethinkdb.Session) *DbConnSession{
	return &DbConnSession{s}
}


//Controller action methods 
func (a DbConnSession) GetAllCustomers(w http.ResponseWriter, r *http.Request, p httprouter.Params) error{
	query :=r.URL.Query()
	
	result, err:= rethinkdb.Table("Customer").Run(a.session)
	if err != nil{
		log.Fatalln(err.Error())
		return err 
	}

	defer result.Close()
	
	var customers []models.Customer 
	err = result.All(&customers)

	if err != nil{
		fmt.Printf("Error scanning database result:%s",err)
		return err
	}

	if query.Get("render") == xml{
		utils.RespondToXML(w,r,p,customers)
		return nil 
	}
	utils.RespondToJSON(w,r,p,customers)
	return nil 

}



//findbyId 
func (a DbConnSession)  FindByCustomerId(w http.ResponseWriter, r *http.Request, p httprouter.Params) error{
	findQuery:=r.URL.Query()
	id :=findQuery.Get("id")

	result, err := rethinkdb.Table("Customer").Filter(map[string]interface{}{
		"Id":id,
	}).Run(a.session)
	if err!=nil{
		log.Fatalln(err.Error())
		return err 
	}

	defer result.Close()

	var customers []models.Customer

	err = result.All(&customers)
	if err != nil{
		fmt.Printf("Error scanning database result:%s",err)
		return err
	}

	if findQuery.Get("render")==xml{
		utils.RespondToXML(w,r,p,customers)
		return nil
	}
	utils.RespondToJSON(w,r,p, customers)
	return nil 
}


//add customer 
func (a DbConnSession) AddCustomer(w http.ResponseWriter, r *http.Request, p httprouter.Params) error{
	addQuery:=r.URL.Query()
	
	newCustomer := new(models.Customer)
	json.NewDecoder(r.Body).Decode(newCustomer)
	fmt.Println("newcustomer records:", newCustomer)

	result, err:=rethinkdb.Table("Customer").Insert(newCustomer).RunWrite(a.session)

	if err !=nil{
		log.Fatalln(err.Error())
		return err
	}

	if addQuery.Get("render") == xml{
		utils.RespondToXML(w,r,p,result)
		return nil 
	}
	utils.RespondToJSON(w,r,p,result)
	return nil 

}



//updating customer 

func (a DbConnSession) UpdateCustomer(w http.ResponseWriter, r *http.Request, p httprouter.Params) error{
	chgQuery := r.URL.Query()
	changeCustomer := new(models.Customer)
	id:=p.ByName("id")
	json.NewDecoder(r.Body).Decode(changeCustomer)

	result, err := rethinkdb.Table("Customer").Get(id).Update(map[string]interface{}{
		   "Id":id, 
	}).RunWrite(a.session)

	if err != nil {
		log.Fatalln(err.Error())
		return err 
	}

	if chgQuery.Get("render") == xml{
		utils.RespondToXML(w,r,p,result)
		return nil 
	}
	utils.RespondToJSON(w,r,p, result)
	return nil 

}


//delete customer 

func (a DbConnSession) DeleteCustomer(w http.ResponseWriter, r *http.Request, p httprouter.Params ) error{
	rmQuery:=r.URL.Query()
	id:=p.ByName("id")

	result,err:=rethinkdb.Table("Customer").Get(id).Delete().RunWrite(a.session)
	if err != nil{
		log.Fatalln(err.Error())
		return err
	}

	if rmQuery.Get("render") == xml {
		utils.RespondToXML(w,r,p, result)
		return nil 
	}
	utils.RespondToJSON(w,r,p,result)
	return nil 
}
