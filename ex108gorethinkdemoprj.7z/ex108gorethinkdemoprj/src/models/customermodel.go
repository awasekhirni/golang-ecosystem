package models 

type Customer struct{
	Id string `json:"id" gorethink:"id,omitempty"`
	CustomerName string `json:"customername" gorethink:"customername"`
	CustomerEmail string `json:"customeremail" gorethink:"customeremail"`
	CustomerType string `json:"customertype" gorethink:"customertype"`
	CustomerAddress string `json:"customeraddress" gorethink:"customeraddress"`
}
