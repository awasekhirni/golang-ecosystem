package router 

import (
	"net/http"
	"../controllers"
	"../config"
	"github.com/julienschmidt/httprouter"
)

type CtrlMiddlewares func(w http.ResponseWriter, r *http.Request, p httprouter.Params) error

func Middleware(m ...CtrlMiddlewares) httprouter.Handle{
	return func(w http.ResponseWriter, r *http.Request, p httprouter.Params){
		for _, middleware :=range m{
			err := middleware(w, r, p)
			if err != nil{
				w.Write([]byte(err.Error()))
				return
			}
		}
	}
}

func Router() *httprouter.Router{
	router := httprouter.New()

	ctrlSession := controllers.AppSession(config.GetSession())

	router.GET("/customer",Middleware(config.Logger,ctrlSession.GetAllCustomers))
	router.GET("/customer/:id",Middleware(ctrlSession.FindByCustomerId))
	router.POST("/customer/add",Middleware(ctrlSession.AddCustomer))
	router.PUT("/customer/update/:id",Middleware(ctrlSession.UpdateCustomer))
	router.DELETE("/customer/delete/:id",Middleware(ctrlSession.DeleteCustomer))
	

   return router 
}