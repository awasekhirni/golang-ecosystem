package utils 

import (
	"compress/gzip"
	"encoding/json"
	"encoding/xml"
	"net/http"
	"github.com/julienschmidt/httprouter"
)


func RespondToJSON(w http.ResponseWriter, r *http.Request, p httprouter.Params, value interface{}){
	w.Header().Add("Content-Type","application/json; charset=UTF-8")
	w.Header().Set("Content-Encoding","gzip")
	w.WriteHeader(http.StatusOK)
	gz := gzip.NewWriter(w)
	defer gz.Close()

	if err := json.NewEncoder(gz).Encode(value); err !=nil{
		w.Header().Set("Content-Type","application/json; charset=UTF-8")
		w.WriteHeader(http.StatusBadRequest)
		return 
	}
}

func RespondToXML(w http.ResponseWriter, r *http.Request, p httprouter.Params, value interface{}){
    w.Header().Add("Content-Type","application/xml; charset=UTF-8")
	w.Header().Set("Content-Encoding","gzip")
	w.WriteHeader(http.StatusOK)
	gz := gzip.NewWriter(w)
	defer gz.Close()

	if err := xml.NewEncoder(gz).Encode(value); err !=nil{
		w.Header().Set("Content-Type","application/xml; charset=UTF-8")
		w.WriteHeader(http.StatusBadRequest)
		return 
	}
}


