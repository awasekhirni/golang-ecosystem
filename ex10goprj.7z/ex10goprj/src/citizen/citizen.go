package citizen

type Citizenship interface{
	GetName() string 
	GetGender() string
	SpeakLanguage() string
}

type Person struct{
	Name string 
	Gender string 
	Language string 
}


type French struct{
	Person 
}

type German struct{
	Person
}



/*constructor function */
func CreateFrenchCitizen(name string) *French{
	return &French{
		Person{"Louis Vuitton","male","french"},
	}
}

/*constructor function*/
func CreateGermanCitizen(name string) *German{
			return &German{
			Person{"Nicolas Hirsch","male","german"},
	}
}

/* implementation methods */

func (g *German) GetName() string{
    return g.Name 
}

func (g *German) GetGender() string{
    return g.Gender 
}

func (g *German) SpeakLanguage() string{
    return g.Language
}

func (f *French) GetName() string{
    return f.Name 
}

func (f *French) GetGender() string{
    return f.Gender 
}

func (f *French) SpeakLanguage() string{
    return f.Language
}


