package main // 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com

import (
	"fmt"
	"./citizen"
)

func main(){
	var c citizen.Citizenship
    
    c=citizen.CreateFrenchCitizen("julie")
    fmt.Println(c.GetName(), "\n",c.GetGender(), "\n", c.SpeakLanguage())

    c=citizen.CreateGermanCitizen("g")
    fmt.Println(c.GetName(), "\n",c.GetGender(), "\n", c.SpeakLanguage())

}