package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import (
	"./music"
)

func main(){
	var player music.BaseGuitarist
    player.Name = "Paul"
    player.PlayGuitar()

    var player2 music.AcousticGuitarist
    player2.Name = "Ringo"
    player2.PlayGuitar()	
}