package music

import ("fmt")

type Guitarist interface{
	//play guitar
	PlayGuitar()
}

type BaseGuitarist struct{
	Name string
}

type AcousticGuitarist struct{
	Name string
}

func(b BaseGuitarist) PlayGuitar() {
	fmt.Printf("%s plays the Bass Guitar\n", b.Name)
}


func (b AcousticGuitarist) PlayGuitar() {
   fmt.Printf("%s plays the Acoustic Guitar\n", b.Name)
}



