package company 

import "fmt"

type Permanent struct{
	EmployeeId int 
	Basicpay int 
	Pf int 
}


type Contract struct{
	EmployeeId int 
	Basicpay int
}


/** interface*/

type SalaryComputation interface {
	ComputeSalary() int
}


/*Compute Salary of the different types of employee*/
func (p Permanent) ComputeSalary() int{
	return p.Basicpay+p.Pf
}


func (c Contract) ComputeSalary() int{
	return c.Basicpay
}

/*Compute total expenses incurred by the company*/
func TotalExpense(s []SalaryComputation) {
	expense := 0
	for _, v := range s {
		expense = expense + v.ComputeSalary()
	}
	fmt.Printf("Total Expense Per Month $%d", expense)
}
