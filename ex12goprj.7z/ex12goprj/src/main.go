package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import "./company"

func main(){
	pone := company.Permanent{1, 50000, 2000}
	ptwo := company.Permanent{2, 8000, 3000}
	cone := company.Contract{3, 40000}
	ctwo := company.Contract{4, 45000}

	employees := []company.SalaryComputation{pone, ptwo, cone, ctwo}
	company.TotalExpense(employees)
}