package internalrepo 

import "fmt"

//internal representation of interfaces demo 

type MyFloat float64

//interface definition
type Tester interface{
	Test()
}

//implementation 
func (mf MyFloat) Test(){
	fmt.Println(mf)
}


func Describe(t Tester){
	fmt.Printf("Interface type %T value %v\n", t, t)
}