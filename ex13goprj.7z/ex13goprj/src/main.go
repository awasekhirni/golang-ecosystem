package main 
import "./internalrepo"
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
func main(){
	var t internalrepo.Tester
	f := internalrepo.MyFloat(102.71)
	t = f
	internalrepo.Describe(t)
	t.Test()
}