package main
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import (
	"fmt"

	"./geom"
)

func main() {

	var s geom.Shape = geom.Circle{5.0}
	fmt.Printf("Shape Type = %T, Shape Value = %v\n", s, s)
	fmt.Printf("Area = %f, Perimeter = %f\n\n", s.Area(), s.Perimeter())

	var s1 geom.Shape = geom.Rectangle{4.0, 6.0}
	fmt.Printf("Shape Type = %T, Shape Value = %v\n", s1, s1)
	fmt.Printf("Area = %f, Perimeter = %f\n", s1.Area(), s1.Perimeter())

}