/* Diamond problem implementation with go*/
package diamond 

import "fmt"

/*interface definitions*/
type A interface{
	Impl()
}

type B struct{
	A
}

func (b B) Impl(){
	fmt.Println("impl() of B")
}

type C struct {
	A
}

func (c C) Impl(){
	fmt.Println("Implementation of C")
}

type D struct{
	B
	C
}

func (d D) Impl(){
	fmt.Println("Implementation of D")
}



