package main
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import (
	"./diamond"
)

func main() {

	dia:=diamond.D{}
	dia.B.Impl()
	dia.C.Impl()
	
}
