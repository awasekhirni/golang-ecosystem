/** composition demo **/
package blog 
import "fmt"

type Author struct{
	FirstName string 
	LastName string 
	Bio string 
}

func(a Author) FullName() string{
	return fmt.Sprintf("%s %s", a.FirstName, a.LastName)
}

type Post struct{
	Title string 
	Content string 
	Author
}

func(p Post) Details(){
	fmt.Println("Title: ", p.Title)
	fmt.Println("Content: ", p.Content)
	fmt.Println("Author: ", p.FullName())
	fmt.Println("Bio: ", p.Bio)
}

type Website struct{
	Posts []Post
}

func (w Website) Contents(){
	fmt.Println("Contents of Website\n")
	for _, v := range w.Posts {
		v.Details()
		fmt.Println()
	}
}