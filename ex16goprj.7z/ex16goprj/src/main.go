package main 
// 2017-18 Copyright Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com or www.sycliq.com
import "./blog"

func main() {

	sak := blog.Author{
		"Awase",
		"Syed",
		"Exploratory Representations for Geographic Information Retrieved from the Internet",
	}

	post1 := blog.Post{
		"Permaforst",
		"Glacier Permaforst",
		sak,
	}
	post2 := blog.Post{
		"Geospatial Intelligence",
		"Geospatial intelligence of south asia",
		sak,
	}
	post3 := blog.Post{
		"Digital Earth Initiative",
		"Are we there yet",
		sak,
	}
	w := blog.Website{
		Posts: []blog.Post{post1, post2, post3}}

	w.Contents()
}