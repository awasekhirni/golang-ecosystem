package main 

import "fmt"

type Kitchen struct{
	numOfLamps int
}

type Bedroom struct{
	numOfLamps int
}

type House struct{
	Kitchen
	Bedroom
}

func main() {
	h := House{Kitchen{2}, Bedroom{3}} //kitchen has 2 lamps, Bedroom has 3 lamps
	fmt.Println("House h has this many lamps:", h.Kitchen.numOfLamps + h.Bedroom.numOfLamps) //refer to fields via type name
   // fmt.Println("Ambiguous number of lamps:", h.numOfLamps) //this is an error due to ambiguousness - is it Kitchen.numOfLamps or Bedroom.numOfLamps
}
