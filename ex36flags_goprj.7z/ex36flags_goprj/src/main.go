package main 

import (
	"flag"
	"fmt"
	"os"
	"time"
	
)

//global variables declaration 
var debug bool
var name string 
var wait time.Duration

// this function is called before the main function
func init(){
	flag.BoolVar(&debug, "debug",false, "Turn on debugging output")
	flag.StringVar(&name,"name","", "the name to say hello to ")
	defaultWait,err:=time.ParseDuration("5s")
	if err !=nil{
		panic("could not parse default wait time!")
	}
	flag.DurationVar(&wait,"wait-time",defaultWait,"Time to wait before printing")
	flag.Parse()

}


func main(){
	if name==""{
		fmt.Println("must add name to use this tool!")
		flag.Usage()
		os.Exit(1)
	}

	if debug{
		fmt.Printf("Going to wiat for %v\n",wait)
	}
	time.Sleep(wait)
	fmt.Println("Hello, %s", name)


}