package main 

import (
	"fmt"
	"os"
	"io/ioutil"
)

func main(){
	writeOperation()
	readOperation()
}


func writeOperation(){
	f,err:=os.Create("output.txt")
	if err!=nil{
		panic("unable to create file")
	}
	defer f.Close()
	count, err :=f.WriteString("Hello!, you fool i love you, come on enjoy the joyride!")
	if err !=nil{
		panic("unable to write file")

	}
	fmt.Printf("Wrote %d bytes\n", count)
}

func readOperation(){
	f, err:=os.Open("output.txt")
	if err!=nil{
		panic("unable to open file")
	}
	defer f.Close()
	buf := make([]byte, 64)
	count, err:=f.Read(buf)
	if err !=nil{
		panic("unable to read file")
	}
	fmt.Printf("Read %d bytes\n",count)
	fmt.Println(string(buf[:count]))
}

func utilOpswrite(){
	err:=ioutil.WriteFile("otherfile.txt",[]byte("Every day the under estimate me! is good for me to prove them wrong, my resolve grows stronger and stronger!"),0644)
	if err !=nil{
		panic("unable to write file")
	}
}

func utilOpsread(){
	ibuff,err:=ioutil.ReadFile("otherfile.txt")
	if err!=nil{
		panic("unable to read file")
	}
	fmt.Println(string(ibuff))
}
