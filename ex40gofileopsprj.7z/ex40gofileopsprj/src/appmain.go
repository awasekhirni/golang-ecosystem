package main 

import (
	"fmt"
	"./utilities"
)


//define the path 
var path ="./data/ex40.txt"
func main(){
	fmt.Println("File Read/Write/Delete/Create Operations Demo!")
	utilities.CreateFile(path)
	utilities.WriteFile(path)
	utilities.ReadFile(path)
	utilities.DeleteFile(path)

}