package main 

import (
	"net/http"
	"./middleware"
)

func main(){

	finalHandler := http.HandlerFunc(middleware.Thirdmiddleware)
	http.Handle("/",middleware.Onemiddleware(middleware.Twomiddleware(finalHandler)))
	http.ListenAndServe(":9898",nil)
}
