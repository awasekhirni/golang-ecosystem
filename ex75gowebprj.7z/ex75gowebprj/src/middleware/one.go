package middleware 

import (
	"fmt"
	"net/http"

)


func Onemiddleware(next http.Handler) http.Handler{
	return http.HandlerFunc(func(response http.ResponseWriter, request *http.Request){
		fmt.Fprintln(response, "Executing First Middleware()...")
		next.ServeHTTP(response,request)
		fmt.Fprintln(response, "Executing FIRST middleware again ____")
	})
}



