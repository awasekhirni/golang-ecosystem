package middleware

import (
	"fmt"
	"net/http"
)


func Thirdmiddleware(w http.ResponseWriter,r *http.Request){
	fmt.Fprintln(w,"Exeucting the third middleware()....")
	fmt.Fprintln(w, "Done")
}