package middleware 

import (
	"fmt"
	"net/http"
)

func Twomiddleware(next http.Handler) http.Handler{
	return http.HandlerFunc(func(writerResponse http.ResponseWriter, readRequest *http.Request){
		fmt.Fprintln(writerResponse,"Executing SECOND middleware()...")
		if readRequest.URL.Path !="/"{
			return
		}
		next.ServeHTTP(writerResponse,readRequest)
		fmt.Fprintln(writerResponse,"Executing SECOND middleware() again.....")
	})
}