package main 

import (
	"net/http"
	"strings"
)


func hello(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("Hello, Simple Web Server Go Lang Demo!"))
	message:=r.URL.Path
	message= strings.TrimPrefix(message,"/")
	message="Hello"+message 
	w.Write([]byte(message))
}


func main(){
	mux:=http.NewServeMux()
	mux.HandleFunc("/",hello)
	httpServer :=http.Server{
		Addr:":9898",
		Handler:mux,
	}
	if err:=httpServer.ListenAndServe();err !=nil{
		panic(err)
	}
}