package customweb

import "net/http"

func About(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("About Page"))
}


func Home(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("Home Page"))
}


func Login(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("Login Page"))
}

func Logout(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("Logout Page"))
}