package customweb

import "net/http"

var Mux=http.NewServeMux()

func RegisterRoutes(){
	Mux.HandleFunc("/home",Home)
	Mux.HandleFunc("/about",About)
	Mux.HandleFunc("/login", Login)
	Mux.HandleFunc("/logout",Logout)
}