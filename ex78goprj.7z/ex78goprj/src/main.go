package main

import (
	"net/http"
	"./customweb"
)

func main(){
	customweb.RegisterRoutes()
	httpServer:= http.Server{
		Addr: ":9898",
		Handler:customweb.Mux,
	}
	httpServer.ListenAndServe()
}