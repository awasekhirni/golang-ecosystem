package main

import (
	"net/http"
	"fmt"
)

func filer(w http.ResponseWriter, r *http.Request){
	w.Write([]byte("renderfiles"))
}


func main(){
	fmt.Println("File Server Demo - Syed Awase")
	http.Handle("/",http.FileServer(http.Dir("./src")))
	http.HandleFunc("/filer",filer)
	if err:=http.ListenAndServe(":9898",nil);err !=nil{
		panic(err)
	}
}