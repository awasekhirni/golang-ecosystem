package blog

import (
	"net/http"
	"fmt"
	"io/ioutil"
)

func loadFile(fileName string) (string,error){
	bytes,err:=ioutil.ReadFile(fileName)
	if err !=nil{
		return "",err
	}
	return string(bytes),nil
}


func Home(w http.ResponseWriter,r *http.Request){
	var body,_=loadFile("./templates/home.html")
	fmt.Fprint(w,body)
}


func About(w http.ResponseWriter,r *http.Request){
	var body,_=loadFile("./templates/about.html")
	fmt.Fprint(w,body)
}

func Login(w http.ResponseWriter,r *http.Request){
	var body,_=loadFile("./templates/login.html")
	fmt.Fprint(w,body)
}

func Logout(w http.ResponseWriter,r *http.Request){
	var body,_=loadFile("./templates/logout.html")
	fmt.Fprint(w,body)
}

func Contact(w http.ResponseWriter,r *http.Request){
	var body,_=loadFile("./templates/contact.html")
	fmt.Fprint(w,body)
}








