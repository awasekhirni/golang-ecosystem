package blog 

import (
	"net/http"
)

var BlogMux=http.NewServeMux()

func RegisterRoutes(){
	BlogMux.HandleFunc("/home",Home)
	BlogMux.HandleFunc("/about",About)
	BlogMux.HandleFunc("/login",Login)
	BlogMux.HandleFunc("/logout",Logout)
	BlogMux.HandleFunc("/contact",Contact)


}