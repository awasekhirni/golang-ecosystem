package main 

import (
	"net/http"
	"./blog"
)

func main(){
	blog.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:blog.BlogMux,
	}
	httpServer.ListenAndServe()
}