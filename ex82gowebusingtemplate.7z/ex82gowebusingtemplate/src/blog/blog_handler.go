package blog

import (
	"encoding/json"
	"html/template"
	"net/http"
	"io/ioutil"
	"../models"
)


func LoadFile(fileName string) (string,error){
	bytes,err:=ioutil.ReadFile(fileName)
	if err !=nil{
		return "",err
	}
	return string(bytes),nil
}

func loadPosts() []models.Post {
	bytes, _ := ioutil.ReadFile("./templates/posts.json")
	var posts []models.Post
	json.Unmarshal(bytes, &posts)

	return posts
}



func Home(w http.ResponseWriter, r *http.Request){
	blog := models.Blog{Title: "Science Blog", Author: "Syed Awase", Header: "National Science"}
	posts := loadPosts()
	viewModel := models.BlogViewModel{Blog: blog, Posts: posts}
	t, _ := template.ParseFiles("./templates/blog.html")
	t.Execute(w, viewModel)

}