package blog 

import "net/http"

var Mux=http.NewServeMux()

func RegisterRoutes(){
	Mux.HandleFunc("/home",Home)
}