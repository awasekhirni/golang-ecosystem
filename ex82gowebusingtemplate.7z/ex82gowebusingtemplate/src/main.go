package main 
//Copyright 2017-18 Syed Awase Khirni awasekhirni@gmail.com www.sycliq.com/ www.territorialprescience.com 
import (
		"./blog"
		"net/http"
)


func main(){
	blog.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:blog.Mux,
	}
	httpServer.ListenAndServe()
}
