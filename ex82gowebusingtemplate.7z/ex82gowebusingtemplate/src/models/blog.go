package models

type Blog struct{
	Title string 
	Author string
	Header string 
}