package models

type BlogViewModel struct{
	Blog Blog
	Posts []Post
}