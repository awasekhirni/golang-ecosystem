package models

type Post struct{
	Title string
	Author string 
	Body string 
	PublishDate string
}
