package mailtemps


type Account struct{
	FirstName string 
	LastName string 
}