package mailtemps 

type Page struct{
	Title string 
	Body string 
}