package mailtemps

import (
	"time"
)

type Purchase struct{
	Date time.Time 
	Description string 
	AmountInCents int 
}