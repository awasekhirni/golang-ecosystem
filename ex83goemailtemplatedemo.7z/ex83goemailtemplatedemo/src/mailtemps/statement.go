package mailtemps

import (
	"time"
)

type Statement struct{
	FromDate time.Time 
	ToDate time.Time 
	Account Account 
	Purchases []Purchase
}