package main 

import (
	"time"
	"html/template"
	"os"
	"fmt"
	"./mailtemps"
	"strings"
)

// The markdown
var markdownText string = `##ABC
> 123`

// The template
var templateText string = `
<head>
  <title>{{.Title}}</title>
</head>

<body>
  {{.Body | markDown}}
</body>
`

// Real blackfriday functionality commented out, using strings.ToLower for demo
func markDowner(args ...interface{}) template.HTML {
	//return template.HTML(blackfriday.MarkdownCommon([]byte(fmt.Sprintf("%s", args...))))
	return template.HTML(strings.ToLower(fmt.Sprintf("%s", args...)))
}



func formatAsDollars(valueInCents int) (string,error){
	dollars:=valueInCents/100
	cents:= valueInCents %100
	return fmt.Sprintf("$%d.%2d",dollars,cents),nil
}


func formatAsDate(t time.Time) string{
	year,month,day:=t.Date()
	return fmt.Sprintf("%d/%d/%d",day,month,year)
}


func urgentNote(acc mailtemps.Account) string{
	return fmt.Sprintf("You have earned 100 VIP points that can be used for purchases")
}


func createMockStatement() mailtemps.Statement{
	return mailtemps.Statement{
		FromDate: time.Date(2017, 1, 1, 0, 0, 0, 0, time.UTC),
		ToDate: time.Date(2017, 2, 1, 0, 0, 0, 0, time.UTC),
		Account: mailtemps.Account{
			FirstName: "Awase",
			LastName: "Syed",
		},
		Purchases: []mailtemps.Purchase {
			mailtemps.Purchase{
				Date: time.Date(2017, 1, 3, 0, 0, 0, 0, time.UTC),
				Description: "iphone",
				AmountInCents: 7483,
			},
			mailtemps.Purchase{
				Date: time.Date(2017, 1, 8, 0, 0, 0, 0, time.UTC),
				Description: "oneplus",
				AmountInCents: 5463,
			},
		},
	}
}


func main(){
	runthis()

	fmap:=template.FuncMap{
		"formatAsDollars":formatAsDollars,
		"formatAsDate":formatAsDate,
		"urgentNote":urgentNote,
	}
	
	t:=template.Must(template.New("./templates/cemail.tmpl").Funcs(fmap).ParseFiles("templates/email.tmpl"))
	err:=t.Execute(os.Stdout,createMockStatement())
	if err!=nil{
		panic(err)
		//fatalln(err)
	}
}

func runthis(){
	// Create a page
	p := &mailtemps.Page{Title: "A Test Demo", Body: markdownText}

	// Parse the template and add the function to the funcmap
	tmpl := template.Must(template.New("page.html").Funcs(template.FuncMap{"markDown": markDowner}).Parse(templateText))

	// Execute the template
	err := tmpl.ExecuteTemplate(os.Stdout, "page.html", p)
	if err != nil {
		fmt.Println(err)
	}
}