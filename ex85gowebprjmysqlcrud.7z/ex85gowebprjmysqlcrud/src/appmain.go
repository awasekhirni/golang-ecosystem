package main 

import (
	"github.com/sirupsen/logrus"
	//"github.com/spf13/cobra"
	//"github.com/spf13/viper"
	//"html/template"
	
	"net/http"
	
	
	"./route"
)





func main(){
	
	route.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:route.AppMux,
	}
	httpServer.ListenAndServe()

	//logging section  
	Formatter := new(logrus.TextFormatter)
    Formatter.TimestampFormat = "02-01-2006 15:04:05"
    Formatter.FullTimestamp = true
    logrus.SetFormatter(Formatter)
    logrus.Info("Some info. Earth is not flat.")
    logrus.Warning("This is a warning")
    logrus.Error("Not fatal. An error. Won't stop execution")
    logrus.Fatal("MAYDAY MAYDAY MAYDAY. Execution will be stopped here")
    logrus.Panic("Do not panic")


}