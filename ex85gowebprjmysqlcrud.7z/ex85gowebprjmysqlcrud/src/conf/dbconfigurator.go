package conf 

import (
	"github.com/sirupsen/logrus"
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"fmt"

)

var database *sql.DB

func OpenDbConn()(db *sql.DB){
	// dbDriver:="mysql"
	// dbUser:="root"
	// dbPass:="dbp@ssw0rd"
	// dbName:="goex84empdb"
	// dbPort:="tcp(127.0.0.1:3306)//"
	// db,err:=sql.Open(dbDriver,dbUser+":"+dbPass+"@/"+dbPort+dbName)
	db, err := sql.Open("mysql", "root:dbp@ssw0rd@tcp(127.0.0.1:3306)/goex84empdb")

	if err!=nil{
		panic(err.Error())
		logrus.Error("Could not Connect to MySQL database")

	}
	fmt.Println("Connected to MySQL Database")
	//fmt.Println(db)
	return db
}