package controller 

import (
	"net/http"
	"html/template"
	"../models"
	"../conf"
	"fmt"
	"log"
	//"io/ioutil"
) 

var t *template.Template





//crud operations 
func List(w http.ResponseWriter, r *http.Request) {
	db := conf.OpenDbConn()
	selDB, err := db.Query("SELECT * FROM Employee ORDER BY id DESC")
	defer db.Close()
    if err != nil {
        panic(err.Error())
    }
    emp := models.Employee{}
    res := []models.Employee{}
    for selDB.Next() {
        var id int
        var name, city string
        err = selDB.Scan(&id, &name, &city)
        if err != nil {
            panic(err.Error())
        }
        emp.Id = id
        emp.Name = name
        emp.City = city
        res = append(res, emp)
	}
	fmt.Println(len(res))
	
    t, err = template.ParseFiles("views/list.html")
    if err != nil {
        panic(err) // handle error
    }

	t.Execute(w,res)

	fmt.Println(len(res))

    
}


func Show(w http.ResponseWriter,r *http.Request){
	db:=conf.OpenDbConn()
	nId:=r.URL.Query().Get("id")
	rows,err:=db.Query("SELECT * FROM Employee WHERE id=?", nId)
	if err !=nil{
		panic(err.Error())
	}
	defer db.Close()

	emp:=models.Employee{}
	for rows.Next(){
		var id int 
		var name,city string 
		err = rows.Scan(&id,&name,&city)
		if err !=nil{
			panic(err.Error())
		}
		emp.Id=id
		emp.Name=name 
		emp.City=city
	}
	t.ExecuteTemplate(w, "/show",emp)
}


//create new employee 
func New(w http.ResponseWriter, r *http.Request){
	t.ExecuteTemplate(w,"/create",nil)
}


func Edit(w http.ResponseWriter, r *http.Request){
	db:=conf.OpenDbConn()
	nId:=r.URL.Query().Get("id")
	rows, err:=db.Query("SELECT * FROM Employee WHERE id=?",nId)
	if err !=nil{
		panic(err.Error())
	}
	defer db.Close()
	emp:=models.Employee{}
	for rows.Next(){
		var id int 
		var name, city string 
		err=rows.Scan(&id,&name,&city)
		if err!=nil{
			panic(err.Error())
		}
		emp.Id=id 
		emp.Name=name 
		emp.City=city
	}
	t.ExecuteTemplate(w, "/edit",emp)

}


//insert 

func Insert(w http.ResponseWriter, r *http.Request){
	db:=conf.OpenDbConn()
	if r.Method=="POST"{
		name:=r.FormValue("name")
		city:=r.FormValue("city")
		insertForm, err:=db.Prepare("INSERT INTO Employee(name, city) VALUES(?,?)")
		if err !=nil{
			panic(err.Error())
		}
		insertForm.Exec(name,city)
		log.Println("INSERT: Name: " + name + " | City: " + city)
	}
	defer db.Close()
	http.Redirect(w,r,"/list",301)
}

func Delete(w http.ResponseWriter, r *http.Request){
	db:=conf.OpenDbConn()
	emp:=r.URL.Query().Get("id")
	deleteForm,err:=db.Prepare("DELETE FROM Employee WHERE id=?")
	if err !=nil{
		panic(err.Error())
	}

	deleteForm.Exec(emp)
	log.Println("DELETE EXECUTED")
	defer db.Close()
	http.Redirect(w,r,"/delete",301)
}


func Update(w http.ResponseWriter, r *http.Request){
	db:=conf.OpenDbConn()
	if r.Method=="POST"{
		name:=r.FormValue("name")
		city:=r.FormValue("city")
		id:=r.FormValue("uid")
		insForm,err :=db.Prepare("UPDATE Employee SET name=?,city=? WHERE id=?")
        if err !=nil{
			panic(err.Error())
		}
		insForm.Exec(name,city,id)
		log.Println("UPDATE: Name: " + name + " | City: " + city)
	}
	defer db.Close()
	http.Redirect(w,r,"/list",301)
}


