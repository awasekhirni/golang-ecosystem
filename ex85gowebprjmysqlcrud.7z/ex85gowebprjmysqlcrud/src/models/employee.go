package models



type Employee struct{
	Id int
	Name string 
	City string 
}