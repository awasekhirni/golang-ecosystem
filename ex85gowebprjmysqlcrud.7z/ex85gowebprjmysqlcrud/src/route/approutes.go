package route

import (
	"net/http"
	"../controller"
)

var AppMux=http.NewServeMux()

func RegisterRoutes(){
	AppMux.HandleFunc("/list",controller.List)
	AppMux.HandleFunc("/show",controller.Show)
	AppMux.HandleFunc("/delete",controller.Delete)
	AppMux.HandleFunc("/create",controller.New)
	AppMux.HandleFunc("/update",controller.Update)
	AppMux.HandleFunc("/edit",controller.Edit)
}