package controller 

import (
	"../config"
	"fmt"
	//"database/sql"
	"../models"
	"html/template"
	"net/http"
)

// type DbConnnectModel struct{
// 	Db *sql.Db
// }

var t *template.Template

func FindAll(w http.ResponseWriter, r *http.Request) {
	db := config.OpenDbConn()
	rows, err := db.Query("SELECT * FROM Customers")
	defer db.Close()
    if err != nil {
        panic(err.Error())
    }
    cust := models.Customer{}
    customers := []models.Customer{}
    for rows.Next() {
        var id,customerId, companyName,contactName, contactTitle,address,city,region, postalCode,country,fax string 
        err = rows.Scan(&id, &customerId, &companyName,&contactName, &contactTitle, &address, &city, &region, &postalCode,&country,&fax)
        if err != nil {
            panic(err.Error())
		}
		cust.Customer_id =id 
		cust.Company_name =customerId 
		cust.Contact_name =contactName
		cust.Contact_title =contactTitle
		cust.Address=address
		cust.City=city
		cust.Region=region 
		cust.Postal_code =postalCode 
		cust.Country=country
		cust.Fax=fax
	
        customers= append(customers, cust)
	}
	fmt.Println(len(customers))
	
    t, err = template.ParseFiles("views/list.html")
    if err != nil {
        panic(err) // handle error
    }

	t.Execute(w,customers)
    
}
