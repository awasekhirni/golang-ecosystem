package models 

type Customer struct{
	Customer_id string 
	Company_name string 
	Contact_name string 
	Contact_title string 
	Address string 
	City string 
	Region string 
	Postal_code string 
	Country string 
	Fax string   
}