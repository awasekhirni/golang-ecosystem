package route 

import (
	"net/http"
	"../controller"
)

var AppMux=http.NewServeMux()

func RegisterRoutes(){
	AppMux.HandleFunc("/findall",controller.FindAll)

}
