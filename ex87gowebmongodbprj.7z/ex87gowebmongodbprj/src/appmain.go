package main 

import (
	"fmt"
	//"github.com/sirupsen/logrus"
	//"github.com/spf13/cobra"
	//"github.com/spf13/viper"
	"net/http"
	"./route"

)


func main(){
    fmt.Println("Ex87gowebcrud using mongodb database")
	route.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:route.AppMux,
	}

	httpServer.ListenAndServe()

}