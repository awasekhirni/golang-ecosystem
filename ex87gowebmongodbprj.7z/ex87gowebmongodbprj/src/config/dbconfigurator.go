package config 

import (
"fmt"
_ "github.com/lib/pq"
"gopkg.in/mgo.v2"
)

//database 
var DB *mgo.Database

//collections 
var Products *mgo.Collection

func init(){
// get a mongo sessions
    // connecting to mongodb with authentication.
    //s, err := mgo.Dial("mongodb://<username>:<password>localhost/bookstore")
    session, err := mgo.Dial("mongodb://localhost/EcommerceDb")
    if err != nil {
        panic(err)
    }

    if err = session.Ping(); err != nil {
        panic(err)
    }
	fmt.Println("You connected to your mongo database.")	
	// Collection
	//c := session.DB(Database).C(Collection)

    DB = session.DB("EcommerceDb")
	Products = DB.C("products")
	


   
}