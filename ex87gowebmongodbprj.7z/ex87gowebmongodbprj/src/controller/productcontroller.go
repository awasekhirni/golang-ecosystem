package controller 

import (
	"net/http"
	"html/template"
	"../models"
	"fmt"

)


var tmpl *template.Template

func FindAll(w http.ResponseWriter, r *http.Request){
	if r.Method !="GET"{
		http.Error(w, http.StatusText(405),
	http.StatusMethodNotAllowed)
	return 
	}

	products,err:=models.AllProducts()
	if err !=nil{
		http.Error(w,http.StatusText(500)+err.Error(),http.StatusInternalServerError)
	    return 
	}

	tmpl,err := template.ParseFiles("views/list.html")
	tmpl.Execute(w,products)

	fmt.Println(len(products))



}