package models 

import (
	"gopkg.in/mgo.v2/bson"
	"../config"
)

type ProductCat struct{
	Sku string            `bson:"sku"`
	Title string          `bson:"title"`
	Description string    `bson:"description"`
	Qty int               `bson:"qty"`
	Pricing int           `bson:"pricing"`
}


func AllProducts()([]ProductCat,error){
	pr:=[]ProductCat{}
	
	err := config.Products.Find(bson.M{}).All(&pr)
	if err !=nil{
		return nil,err
	}
	return pr,nil
}