package config 

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	_ "github.com/go-sql-driver/mysql"
    "../model"

)


var database *sql.DB 

//connection to the database 
func OpenDbConnect(){

	db, err := sql.Open("mysql", "root:dbp@ssw0rd@tcp(127.0.0.1:3306)/ex88godb")
	if err!=nil{
		log.Println("Could not connect to MySQL database")
	}
	
	log.Println("Connected to MySQL Database - Successful!!")
    database =db 

}

//fetch all the product records and return as JSON 
func DbProductList() []byte{
	var products model.Products
	var product model.Product 

	productResults,err:=database.Query("Select * from product")
	if err!=nil{
		log.Fatal(err)
	}

//lets differ closing 
defer productResults.Close()

for productResults.Next(){
	productResults.Scan(&product.Id, &product.Name, &product.Desc, &product.Price, &product.Qty)
	products=append(products,product)
}

jsonProducts,err:=json.Marshal(products)
	if err !=nil{
		fmt.Println("Error: %s",err)
	}
	return jsonProducts
}


//find a single product based on ID and return as JSON 
func DbProductDisplay(id int) []byte{
	var product model.Product 
	err:=database.QueryRow("SELECT * FROM product where ID=?",id).Scan(&product.Id,&product.Name, &product.Desc, &product.Price, &product.Qty)
	if err !=nil{
		log.Fatal(err)
	}
	jsonProduct,err:=json.Marshal(product)
	if err!=nil{
		fmt.Println("Error:%s",err)
	}
	return jsonProduct

}


func DbProductAdd(product model.Product)[]byte{
	var addResult DbUpdate 
  //creating a prepared statement 
  stmt, err:=database.Prepare("INSERT INTO Product(Name, Desc,Price,Qty) VALUES(?,?,?,?)")
  if err!=nil{
	  log.Fatal(err)
  }

  res,err:=stmt.Exec(product.Name, product.Desc,product.Price,product.Qty)
  if err !=nil{
	  log.Fatal(err)
  }
  lastId,err :=res.LastInsertId()
  if err!=nil{
	  log.Fatal(err)
  }
  rowCnt,err:=res.RowsAffected()
  if err!=nil{
	  log.Fatal(err)
  }

  //populate DbUpdate struct with last id and num rows affected 
  addResult.Id=lastId 
  addResult.Affected=rowCnt 
  //convert to JSON and return 
  newProduct, err:= json.Marshal(addResult)
  if err !=nil{
	  fmt.Printf("Error:%s",err)
  }
  return newProduct
}



//delete the product with given id 
func DbProductDelete(id int64) []byte{
	var deleteResult DbUpdate 
	//create a prepared statement 
	stmt,err:=database.Prepare("DELETE from Product where ID=?")
	if err !=nil{
		log.Fatal(err)
	}

	//execute the prepared statement and retrieve the result s
	res, err:=stmt.Exec(id)
	if err !=nil {
		log.Fatal(err)
	}

	rowCnt,err:=res.RowsAffected()
	if err !=nil{
		log.Fatal(err)
	}

	//populate the Dbupdate with last id and num rows affected 
	deleteResult.Id=id 
	deleteResult.Affected=rowCnt 
	//convert to JSON and return 
	deletedCity,err:=json.Marshal(deleteResult)
	if err!=nil{
		fmt.Printf("Error:%s",err)
	}
	return deletedCity

}


