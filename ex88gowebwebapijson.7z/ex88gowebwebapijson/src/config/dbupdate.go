package config 

type DbUpdate struct{
	Id int64 `json:"id"`
	Affected int64 `json:"affected"`
}