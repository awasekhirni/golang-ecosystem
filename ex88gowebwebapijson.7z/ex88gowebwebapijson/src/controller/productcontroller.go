package controller 

import (
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"strconv"
	"github.com/gorilla/mux"
	"../config"
	"../model"
)

func HomePage(w http.ResponseWriter, r *http.Request){
	fmt.Fprintln(w, "Welcome to Flipkart Dummy Ecommerce Application")
}


func ProductList(w http.ResponseWriter, r * http.Request){
	//Query the databse 
	jsonProducts:=config.DbProductList()

	//Format the response 
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonProducts)
}


func ProductDisplay(w http.ResponseWriter, r *http.Request){
	//get the URL request parameter with product id 
	vars :=mux.Vars(r)
	productId,_:=strconv.Atoi(vars["id"])
	//Query the database 
	jsonProduct :=config.DbProductDisplay(productId)
	//format the response 
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonProduct)
}



func ProductAdd(w http.ResponseWriter, r *http.Request){
	var product model.Product 

	//read the body of the request 
	body, err:=ioutil.ReadAll(io.LimitReader(r.Body,1048576))
	if err !=nil{
		panic(err.Error())
	}
	if err:=r.Body.Close(); err !=nil{
		panic(err)
	}

	if err:= json.Unmarshal(body, &product); err !=nil{
		w.Header().Set("Content-Type","application/json")
		w.WriteHeader(422)
		if err :=json.NewEncoder(w).Encode(err); err !=nil{
			panic(err)
		}
	}
	//writing to the databse 
	addResult :=config.DbProductAdd(product)
	//format the response 
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(addResult)
}


func ProductDelete(w http.ResponseWriter, r *http.Request){
	vars :=mux.Vars(r)
	productId,_:=strconv.ParseInt(vars["id"],10,64)
	//query the database
	deleteResult :=config.DbProductDelete(productId)

	//format the response 
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(deleteResult)
}