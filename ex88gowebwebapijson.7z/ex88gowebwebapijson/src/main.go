package main 

import (
	//"log"
	"net/http"
	"./route"
	"./config"
)


func main(){
	router:=route.NewRouter()
	config.OpenDbConnect()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:router,
	}
	httpServer.ListenAndServe()


}