package route 

import (
	"net/http"
	"../controller"
)


type Route struct{
	Name string 
	Method string 
	Pattern string
	HandlerFunc http.HandlerFunc 
}


type Routes []Route

var routes = Routes{
	Route{
		"HomePage",
		"GET",
		"/",
		controller.HomePage,
	},
	Route{
		"ProductList",
		"GET",
		"/products",
		controller.ProductList,
	},
	Route{
		"ProductDisplay",
		"GET",
		"/product/{id}",
		controller.ProductDisplay,
	},
	Route{
		"ProductAdd",
		"POST",
		"/productadd",
		controller.ProductAdd,
	},
	Route{
		"ProductDelete",
		"GET",
		"/productdelete/{id}",
		controller.ProductDelete,
	},
}