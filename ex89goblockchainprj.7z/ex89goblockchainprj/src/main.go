package main 

import (
	"fmt"
	"./model"
)

func main(){
	bc:=model.NewBlockchain()

	bc.AddBlock("Send 100 BTC to Syed Awase")
	bc.AddBlock("Send 200 BTC to Syed Awase")
	bc.AddBlock("Send 300 BTC to Syed Awase")
	fmt.Println(len(bc.Blocks))
	for _, block:=range bc.Blocks{
		fmt.Println("Prev. hash: %x", block.PrevBlockHash)
		fmt.Println("Data: %s", block.Data)
		fmt.Println("Hash: %x", block.Hash)
		fmt.Println()

	}
}