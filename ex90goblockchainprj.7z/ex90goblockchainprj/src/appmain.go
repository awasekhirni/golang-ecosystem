package main

import (
	"fmt"
	//"github.com/joho/godotenv"
	"./controller"
	"./model"
	"./route"
	//"log"
	"time"
	//"os"
	"net/http"
	"github.com/davecgh/go-spew/spew"
	"sync"

)


var mutex = &sync.Mutex{}

func main(){
	fmt.Println("Go lang blockchain demo!")
	//load the environment files and check them 
	// err:=godotenv.Load()
	// if err !=nil{
	// 	log.Fatal(err)
	// }
	//register the routes
	route.RegisterRoutes()
	//parse the port from env file
	//httpPort:=os.Getenv("PORT")
    //http server configuration parameters
	httpServer:=http.Server{
		Addr:  ":9898" , //+ httpPort
		Handler:        route.AppMux,
		ReadTimeout:    10 * time.Second,
		WriteTimeout:   10 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}

	// if err := httpServer.ListenAndServe(); err!=nil{
	// 	return err
	// }
	
	//concurrent function annonymous function
	go func(){
		t:=time.Now()
		genesisBlock:=model.Block{}
		genesisBlock = model.Block{0, t.String(), 0, controller.ComputeHash(genesisBlock), ""}
		spew.Dump(genesisBlock)

		mutex.Lock()
		model.Blockchain = append(model.Blockchain, genesisBlock)
		mutex.Unlock()
	}()

	
	//list and serve 
	

	httpServer.ListenAndServe()
}