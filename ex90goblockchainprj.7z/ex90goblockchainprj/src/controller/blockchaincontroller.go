package controller 

import (
	  "../model"
	  "sync"
	  "io"
	  "net/http"
	  "encoding/json"
	  "encoding/hex"
	  "crypto/sha256"
	  "strconv"
	  "time"
	  "github.com/davecgh/go-spew/spew"
)


var mutex=&sync.Mutex{}

//fetch all blocks in blockchain 
func GetBlockchain(w http.ResponseWriter, r *http.Request){
	bytes, err :=json.MarshalIndent(model.Blockchain,""," ")
	if err !=nil{
		http.Error(w, err.Error(),http.StatusInternalServerError)
		return
	}
	io.WriteString(w,string(bytes))
}


func CreateBlock(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	var msg model.Message 
	decoder:=json.NewDecoder(r.Body)
	if err :=decoder.Decode(&msg); err!=nil{
		RenderJSON(w,r,http.StatusBadRequest,r.Body)
		return
	}
	defer r.Body.Close()

	mutex.Lock()
	prevBlock:=model.Blockchain[len(model.Blockchain)-1]
	newBlock:=GenerateBlock(prevBlock,msg.BPM)

	if IsValidBlock(newBlock, prevBlock){
		model.Blockchain=append(model.Blockchain,newBlock)
		spew.Dump(model.Blockchain)
	}

	mutex.Unlock()
	RenderJSON(w,r,http.StatusCreated,newBlock)


}


//render JSON 
func RenderJSON(w http.ResponseWriter, r *http.Request, code int, payload interface{}){

	response,err:=json.MarshalIndent(payload, ""," ")
	if err !=nil{
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("HTTP 500:Internal Server Error"))
		return 
	}
	w.WriteHeader(code)
	w.Write(response)

}



func GenerateBlock(oldBlock model.Block, BPM int) model.Block{
	var newBlock model.Block 
	t:=time.Now()
	newBlock.Index = oldBlock.Index +1 
	newBlock.Timestamp=t.String()
	newBlock.BPM = BPM 
	newBlock.PrevHash = oldBlock.Hash 
	newBlock.Hash = ComputeHash(newBlock)
	return newBlock
}

func ComputeHash(block model.Block) string{
	record:=strconv.Itoa(block.Index)+block.Timestamp+strconv.Itoa(block.BPM)+block.PrevHash
	h:=sha256.New()
	h.Write([]byte(record))
	hashed:=h.Sum(nil)
	return hex.EncodeToString(hashed)

}


//check for valid block 

func IsValidBlock(newBlock,oldBlock model.Block) bool{
	if oldBlock.Index+1!=newBlock.Index{
		return false
	}

	if oldBlock.Hash != newBlock.PrevHash{
		return false
	}

	if ComputeHash(newBlock) !=newBlock.Hash{
		return false
	}

	return true
}

