package model 



type Message struct{
	BPM int
}