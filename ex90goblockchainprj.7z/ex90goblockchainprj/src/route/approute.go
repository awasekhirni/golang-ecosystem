package route 

import (
	"net/http"
	"../controller"
)

var AppMux=http.NewServeMux()

func RegisterRoutes(){
	//used as value
	// AppMux.HandleFunc("/get",controller.GetBlockchain).Methods("GET")
	// AppMux.HandleFunc("/create",controller.CreateBlock).Methods("POST")

	AppMux.HandleFunc("/get",controller.GetBlockchain)
	AppMux.HandleFunc("/create",controller.CreateBlock)
}