package main 

import (
	 "fmt"
	"net/http"
	//  "database/sql"
	//  "flag"
	//  "io/ioutil"
	//  "log"
	//  "math"
	//  "os"
	//  "strconv"
	//  "strings"
	//  "time"
	 // "github.com/ChimeraCoder/anaconda"
	"github.com/dghubble/go-twitter/twitter"
	 "./config"
	"./route" 
)


// const header = "#YY  MM DD hh mm WDIR WSPD GST  WVHT   DPD   APD MWD   PRES  ATMP  WTMP  DEWP  VIS PTDY  TIDE\n#yr  mo dy hr mn degT m/s  m/s     m   sec   sec degT   hPa  degC  degC  degC  nmi  hPa    ft"




func main(){
 fmt.Println("Twitter Bot using golang demo tweeting weather data example")
 
 c:=config.OpenTwitterConn()
 config.OpenDbConn()


 // Search tweets to retweet
	searchParams := &twitter.SearchTweetParams{
		Query:      "#golang",
		Count:      5,
		ResultType: "recent",
		Lang:       "en",
	}

	searchResult, _, _ := c.Search.Tweets(searchParams)

        // Retweet
	for _, tweet := range searchResult.Statuses {
		tweet_id := tweet.ID
		c.Statuses.Retweet(tweet_id, &twitter.StatusRetweetParams{})

		fmt.Printf("RETWEETED: %+v\n", tweet.Text)
	}

	

 
route.RegisterRoutes()
	httpServer:=http.Server{
 		Addr:":9898",
		Handler:route.AppMux,
 	}
 	httpServer.ListenAndServe()
}