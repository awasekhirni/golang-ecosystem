package config

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"fmt"
	twitter "github.com/dghubble/go-twitter/twitter"
	oauth1 "github.com/dghubble/oauth1"
	"log"
    
)

func OpenTwitterConn() *twitter.Client{
	
	consumerKey:= "oy3WJA6TsCF7Ti9LCynqzUu0h"
	consumerSecret:= "Z6vXgx36ewS8MJIvuPX8V5hqJNJ1H6rpQ390V91kqYMa8HX1HE"
	accessToken:= "17016172-bSoMnqHx0miG1ifAogGZZU9UAXX6qpV1PrvleUaY5"
	accessSecret:= "s2yLcA2r12hVSih3jkSY2jSM6L2tesSSmNSTy3F5wvTAP"

	config := oauth1.NewConfig(consumerKey, consumerSecret)
	token := oauth1.NewToken(accessToken, accessSecret)

	// OAuth1 http.Client will automatically authorize Requests
	httpClient := config.Client(oauth1.NoContext, token)

	// Twitter client
	client := twitter.NewClient(httpClient)

	// Verify Credentials
	verifyParams := &twitter.AccountVerifyParams{
		IncludeEmail: twitter.Bool(true),
	}
	user, _, _ := client.Accounts.VerifyCredentials(verifyParams)
	fmt.Printf("User's Name:%+v\n", user.ScreenName)
	return client
}

func OpenDbConn()(db *sql.DB){

	 db, err := sql.Open("mysql", "root:dbp@ssw0rd@tcp(127.0.0.1:3306)/ex92gotwitterdb?parseTime=true")


	if err!=nil{
		panic(err.Error())
	}
// Check database connection
err = db.Ping()
if err != nil {
	log.Fatal("Error: Could not establish connection with the database.", err)
}

	
	fmt.Println("Connected to MySQL Database")
	fmt.Println(db)
	return db
}