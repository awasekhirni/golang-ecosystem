package controller 

import(
   "../model"
   "../config"
   "time"
   //"github.com/dghubble/go-twitter/twitter"
   "github.com/ChimeraCoder/anaconda"
   "fmt"
   "net/http"
   
   

)


//twitter query functions 

// func QueryTwitter(sp model.SearchParam, w http.ResponseWriter, r *http.Request){

// 	c=config.OpenTwitterConn()

//     searchParams:=&twitter.SearchTweetParams{
// 		Query:sp.query,
// 		Count:sp.count,
// 		ResultType:sp.resulType,
// 		Lang: lang,
// 	}
// 	searchResult ,_,_:=c.Search.Tweets(searchParams)
// 	fmt.PrintF(searchResult)
// }

func Post2Twitter(w http.ResponseWriter,r *http.Request){
	fmt.Println("Preparing to tweet from bot")

	consumerKey:= "oy3WJA6TsCF7Ti9LCynqzUu0h"
	consumerSecret:= "Z6vXgx36ewS8MJIvuPX8V5hqJNJ1H6rpQ390V91kqYMa8HX1HE"
	accessToken:= "17016172-bSoMnqHx0miG1ifAogGZZU9UAXX6qpV1PrvleUaY5"
	accessSecret:= "s2yLcA2r12hVSih3jkSY2jSM6L2tesSSmNSTy3F5wvTAP"
   
	api := anaconda.NewTwitterApiWithCredentials(accessToken, accessSecret, consumerKey, consumerSecret)
	tweet,err:=api.PostTweet("This tweet is from golang twitter bot! Mike testing 123",nil)
	if err!=nil{
		fmt.Println("update error:",err)

	}else {
		fmt.Println("tweet posted:")
		fmt.Println(tweet.Text)
	}
}

func PostfromDb(w http.ResponseWriter,r *http.Request){
	fmt.Println("Preparing to tweet from database")
	consumerKey:= "oy3WJA6TsCF7Ti9LCynqzUu0h"
	consumerSecret:= "Z6vXgx36ewS8MJIvuPX8V5hqJNJ1H6rpQ390V91kqYMa8HX1HE"
	accessToken:= "17016172-bSoMnqHx0miG1ifAogGZZU9UAXX6qpV1PrvleUaY5"
	accessSecret:= "s2yLcA2r12hVSih3jkSY2jSM6L2tesSSmNSTy3F5wvTAP"
   


	api := anaconda.NewTwitterApiWithCredentials(accessToken, accessSecret, consumerKey, consumerSecret)

	//connect to the database 
	db := config.OpenDbConn()
	rows, err := db.Query("SELECT * FROM `ex92gotwitterdb`.`mystation`;")
	defer db.Close()
    if err != nil {
        panic(err.Error())
    }
    station := model.Mystation{}
    stations := []model.Mystation{}
    for rows.Next() {
		var DateTime time.Time
		var ID,HumOutCur,HumInCur,WindDirCur,WindDirAvg10 int64
		var TempOutCur,  PressCur, DewCur, HeatIdxCur, WindChillCur, TempInCur,  WindSpeedCur, WindAvgSpeedCur, WindGust10,  RainRateCur, RainDay, RainYest, RainMonth, RainYear float64

		var WindDirCurEng, WindDirAvg10Eng string 
        err = rows.Scan(&ID, &DateTime, &TempOutCur, &HumOutCur, &PressCur, &DewCur, &HeatIdxCur, &WindChillCur, &TempInCur, &HumInCur, &WindSpeedCur, &WindAvgSpeedCur, &WindDirCur, &WindDirCurEng, &WindGust10, &WindDirAvg10, &WindDirAvg10Eng, &RainRateCur, &RainDay, &RainYest, &RainMonth, &RainYear)
        if err != nil {
            panic(err.Error())
        }
        station.ID = ID
        station.DateTime = DateTime
		station.HumOutCur = HumOutCur
		station.HumInCur=HumInCur 
		station.WindDirCur=WindDirCur
		station.WindDirAvg10=WindDirAvg10 
		station.TempOutCur=TempOutCur 
		station.PressCur =PressCur 
		station.DewCur=DewCur 
		station.HeatIdxCur =HeatIdxCur 
		station.WindChillCur=WindChillCur 
		station.TempInCur = TempInCur 
		station.WindSpeedCur=WindSpeedCur 
		station.WindAvgSpeedCur=WindAvgSpeedCur 
		station.WindDirCur =WindDirCur
		station.WindAvgSpeedCur=WindAvgSpeedCur
		station.WindDirCur=WindDirCur
		station.WindDirCurEng=WindDirCurEng
		station.WindGust10=WindGust10
		station.WindDirAvg10=WindDirAvg10
		station.WindDirAvg10Eng=WindDirAvg10Eng
		station.RainRateCur=RainRateCur
		station.RainDay=RainDay
		station.RainYest=RainYest
		station.RainMonth=RainMonth
		station.RainYear=RainYear
fmt.Println(station)
        stations = append(stations, station)
	}
	
	fmt.Println(len(stations))

	//iterate and publish on twitter 	
	
	//tweet,err:=api.PostTweet("In the subsequent tweets, you shall see some weather data tweeted by golang bot iteratively",nil)
	for i, s := range stations {
		fmt.Println(i, s)
		
		tweet,err:=api.PostTweet(s.String(),nil)
		if err!=nil{
			fmt.Println("update error:",err)
			}else {
			fmt.Println("tweet posted:")
			fmt.Println(tweet.Text)
		}
	}

}



