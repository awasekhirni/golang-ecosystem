package model 

type Config struct{
	UserName string `json:"UserName"`
	ConsumerKey string `json:"ConsumerKey"`
	Token string `json:"Token"`
	TokenSecret string `json:"TokenSecret"`
	DatabaseURL string `json:"DatabaseUrl"`
	DatabaseUser string `json:"DatabaseUser"`
	DatabasePassword string `json:"DatabasePassword"`
	DatabaseName string `json:"DatabaseName"`
}