package model 

import (
	"time" 
	"fmt"
)

type Mystation struct{

	ID int64
	DateTime time.Time
	TempOutCur float64
	HumOutCur int64
	PressCur float64 
	DewCur float64 
	HeatIdxCur float64
	WindChillCur float64 
	TempInCur float64 
	HumInCur int64
	WindSpeedCur float64 
	WindAvgSpeedCur float64 
	WindDirCur int64
	WindDirCurEng string
	WindGust10 float64 
	WindDirAvg10 int64
	WindDirAvg10Eng string 
	RainRateCur float64 
	RainDay float64 
	RainYest float64 
	RainMonth float64 
	RainYear float64
}


//string makes object satisfy the Stringer interface 

func (m Mystation) String() string{
	return fmt.Sprintf("%v %v %f %d %f %f %f %f %f %d %f %f %d %v %f %f %f %f %f %f %f %f %f %f ",m.ID, m.DateTime, m.TempOutCur, m.HumOutCur, m.PressCur, m.DewCur, m.HeatIdxCur, m.WindChillCur, m.TempInCur, m.HumInCur, m.WindSpeedCur, m.WindAvgSpeedCur, m.WindDirCur, m.WindDirCurEng, m.WindGust10, m.WindDirAvg10, m.WindDirAvg10Eng, m.RainRateCur, m.RainDay, m.RainYest, m.RainMonth, m.RainYear)
}


