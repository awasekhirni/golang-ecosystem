package model 

type SearchParam struct{
	query string 
	count int 
	resultType string 
	lang string 
}