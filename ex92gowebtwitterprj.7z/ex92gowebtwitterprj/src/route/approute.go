package route 

import (
	"net/http"
	"../controller"
)

var AppMux=http.NewServeMux()

func RegisterRoutes(){
	//AppMux.HandleFunc("/searchtweet",controller.QueryTwitter)
	AppMux.HandleFunc("/posttweet",controller.Post2Twitter)
	AppMux.HandleFunc("/tweetfromdb",controller.PostfromDb)
}
