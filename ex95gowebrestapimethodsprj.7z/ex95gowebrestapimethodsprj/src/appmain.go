
package main 

import (
	"fmt"
	"net/http"
	"./route"
)

func main(){
	fmt.Println("Ex95goswagger demo rest api")
	route.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:route.AppRouter,
	}
	httpServer.ListenAndServe()
	
}