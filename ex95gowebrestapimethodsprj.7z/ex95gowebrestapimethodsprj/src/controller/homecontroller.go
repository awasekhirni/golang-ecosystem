package controller 

import (
	"fmt"
	"net/http"
	"strconv"
	"github.com/gorilla/mux"
)


func GetOperation(w http.ResponseWriter, r *http.Request){
    w.Header().Set("Access-Control-Allow-Origin", "*")
w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"message":"GET REQUEST OPERATION"}`))
}


func PostOperation(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte(`{"message":"POST REQUEST  OPERATION"}`))
}


func DeleteOperation(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"message":"DELETE REQUEST  OPERATION"}`))
}


func PutOperation(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusAccepted)
	w.Write([]byte(`{"message":"PUT REQUEST  OPERATION"}`))
}


func ParamsRequested(w http.ResponseWriter, r *http.Request) {
    pathParams := mux.Vars(r)
    w.Header().Set("Content-Type", "application/json")

    userId := -1
    var err error
    if val, ok := pathParams["userId"]; ok {
        userId, err = strconv.Atoi(val)
        if err != nil {
            w.WriteHeader(http.StatusInternalServerError)
            w.Write([]byte(`{"message": "Please provide UserId"}`))
            return
        }
    }

    commentId := -1
    if val, ok := pathParams["commentId"]; ok {
        commentId, err = strconv.Atoi(val)
        if err != nil {
            w.WriteHeader(http.StatusInternalServerError)
            w.Write([]byte(`{"message": "need a number"}`))
            return
        }
    }

    query := r.URL.Query()
    location := query.Get("location")

    w.Write([]byte(fmt.Sprintf(`{"userId": %d, "commentId": %d, "location": "%s" }`, userId, commentId, location)))
}


