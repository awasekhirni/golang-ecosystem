package route 

import (
	
	"../controller"
	"github.com/gorilla/mux"

)

 var AppRouter =mux.NewRouter()

func RegisterRoutes(){



	AppRouter.HandleFunc("/fetch",controller.GetOperation).Methods("GET")
	AppRouter.HandleFunc("/change",controller.PutOperation).Methods("PUT")
	AppRouter.HandleFunc("/update",controller.PostOperation).Methods("POST")
	AppRouter.HandleFunc("/remove",controller.DeleteOperation).Methods("DELETE")
	AppRouter.HandleFunc("params",controller.ParamsRequested).Methods("GET")


}