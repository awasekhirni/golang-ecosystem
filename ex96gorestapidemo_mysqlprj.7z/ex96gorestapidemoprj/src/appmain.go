package main 

import (
	"fmt"
	"log"
	"net/http"
	
	"./router"

	
)



func main(){
	fmt.Println("Example 96 go REST API DEMO PRJ")
	
	router.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:router.AppRouter,
	}

	log.Fatal(httpServer.ListenAndServe())
}