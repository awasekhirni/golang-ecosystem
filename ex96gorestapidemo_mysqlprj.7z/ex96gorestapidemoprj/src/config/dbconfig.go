package config

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
   "fmt"
   "log"
)


func OpenDbConn()(db *sql.DB){

	db, err := sql.Open("mysql", "root:dbp@ssw0rd@tcp(127.0.0.1:3306)/ex96gorestapidb")


   if err!=nil{
	   panic(err.Error())
   }
// Check database connection
err = db.Ping()
if err != nil {
   log.Fatal("Error: Could not establish connection with the database.", err)
}

   
   fmt.Println("Connected to MySQL Database")
   fmt.Println(db)
   return db
}