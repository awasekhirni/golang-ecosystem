package controller 

import (
	"encoding/json"
	"net/http"
	"fmt"
	"../model"
	"../config"
	 "github.com/gorilla/mux"
	 "strconv"
	 //"io/ioutil"
	 "log"
	
	
)


//GetAllBooks 
func GetAllBooks(w http.ResponseWriter, r *http.Request){
	fmt.Println("Get All Books function called")
	//Format the response 
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	db:=config.OpenDbConn()
	rows,err:=db.Query("SELECT * FROM book")
	defer db.Close()
    if err != nil {
        panic(err.Error())
	}
	book:=model.Book{}
	books:=[]model.Book{}
	for rows.Next(){
		
	var title,author,country, language,imageLink,link string 
	var id, year, pages int 
		err=rows.Scan(&id,&author,&country,&imageLink,&language,&link,&pages, &title,&year)
		if err!=nil{
			panic(err.Error())
		}
		book.ID=id 
		book.Title=title 
		book.Author=author 
		book.Language = language 
		book.Year = year 
		book.ImageLink=imageLink 
		book.Pages = pages 
		book.Link=link 
		book.Country=country
	

	books=append(books,book)
	}
	json.NewEncoder(w).Encode(books)
	

} 

func GetBookbyId(w http.ResponseWriter, r *http.Request){
	//Format the response 
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
    fmt.Println("Get Book by Id function called")
	 db:=config.OpenDbConn()
	
	params:=mux.Vars(r)
	i,_:=strconv.Atoi(params["id"])

	rows,err :=db.Query("Select * from Book WHERE ID=?",i)
	 if err !=nil{
		 panic(err.Error())
	 }

	 defer db.Close()
	 book:=model.Book{}
	 for rows.Next(){
		var title,author,country, language,imageLink,link string 
		var id, year, pages int 
			err=rows.Scan(&id,&author,&country,&imageLink,&language,&link,&pages, &title,&year)
			if err!=nil{
				panic(err.Error())
			}
			book.ID=id 
			book.Title=title 
			book.Author=author 
			book.Language = language 
			book.Year = year 
			book.ImageLink=imageLink 
			book.Pages = pages 
			book.Link=link 
			book.Country=country
			
	 }
	 json.NewEncoder(w).Encode(book)
	} 



func CreateBook(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Create Book function called")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
	w.Header().Set("Content-Type","application/json")

    db := config.OpenDbConn()
    if r.Method == "POST" {
	   author:=r.FormValue("author")
	   language:=r.FormValue("language")
	   year :=r.FormValue("year")
	   imageLink:=r.FormValue("imageLink")
	   pages:=r.FormValue("pages")
	   link:=r.FormValue("link")
	   title:=r.FormValue("title")
	   country:=r.FormValue("country")
		
        insForm, err := db.Prepare("INSERT INTO `ex96gorestapidb`.`book` 	(	`author`,`country`,`imageLink`,	`language`,	`link`,	`pages`,`title`,`year`) VALUES 	(?,?,?,?,?,?,?,?)")
        if err != nil {
            panic(err.Error())
        }
        insForm.Exec(author, country, imageLink, language, link, pages, title, year)
        fmt.Println(author,country,imageLink,language,link,pages, title, year)
    }
    defer db.Close()
    http.Redirect(w, r, "/books", 301)
}


func EditBook(w http.ResponseWriter, r *http.Request) {
    db := config.OpenDbConn()
    params:=mux.Vars(r)
	nId,_:=strconv.Atoi(params["id"])
	fmt.Println(nId)
    rows, err := db.Query("SELECT * FROM Book WHERE ID=?", nId)
    if err != nil {
        panic(err.Error())
	}
	defer db.Close()
    book := model.Book{}
    for rows.Next(){
		var title,author,country, language,imageLink,link string 
		var id, year, pages int 
			err=rows.Scan(&id,&author,&country,&imageLink,&language,&link,&pages, &title,&year)
			if err!=nil{
				panic(err.Error())
			}
			book.ID=id 
			book.Title=title 
			book.Author=author 
			book.Language = language 
			book.Year = year 
			book.ImageLink=imageLink 
			book.Pages = pages 
			book.Link=link 
			book.Country=country
			
	 }
	 json.NewEncoder(w).Encode(book)
    
}


func UpdateBook(w http.ResponseWriter, r *http.Request){
	fmt.Println("Update Book function called")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "PUT, OPTIONS")
	w.Header().Set("Content-Type","application/json")
	w.WriteHeader(http.StatusOK)
	db:=config.OpenDbConn()

	if r.Method=="POST" {
		id:=r.FormValue("id")
		author:=r.FormValue("author")
		language:=r.FormValue("language")
		year :=r.FormValue("year")
		imageLink:=r.FormValue("imageLink")
		pages:=r.FormValue("pages")
		link:=r.FormValue("link")
		title:=r.FormValue("title")
		country:=r.FormValue("country")
	updateForm,err:=db.Prepare("UPDATE `ex96gorestapidb`.`book` SET `id` = ?,`author` = ?, `country` = ?,`imageLink` = ?,`language` = ?, `link` = ?,`pages` = ?, `title` = ?,`year` = ? WHERE `id` = ?")
		if err!=nil{
			panic(err.Error())
		}
		updateForm.Exec(author, country, imageLink, language, link, pages, title, year,id)
        fmt.Println(author,country,imageLink,language,link,pages, title, year,id)
	}
	defer db.Close()

	http.Redirect(w,r,"/books",301)
		
} 



func RemoveBook(w http.ResponseWriter, r *http.Request){
	fmt.Println("Get All Books function called")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "DELETE, OPTIONS")
	w.Header().Set("Content-Type","application/json")
	db:=config.OpenDbConn()
	
	params:=mux.Vars(r)
    id,_:=strconv.Atoi(params["id"])

	
    //book := r.URL.Query().Get("id")
    status, err := db.Query("DELETE FROM book WHERE id=?",id)
    if err != nil {
        panic(err.Error())
    }
    //delForm.Exec(book)
	log.Println("DELETE")
	fmt.Println("DELETE Successful",status)
    defer db.Close()
    http.Redirect(w, r, "/books", 301)
} 