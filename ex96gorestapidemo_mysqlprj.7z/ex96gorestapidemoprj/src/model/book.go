package model 

import (

)

type Book struct{
	ID int `json:id`
	Title string `json:title`
	Author string `json:author`
	Year int `json:year`
	Country string `json:country`
	Language string `json:language`
	ImageLink string `json:imageLink`
	Link string `json:imageLink`
	Pages int `json:pages`
}

var Books []Book