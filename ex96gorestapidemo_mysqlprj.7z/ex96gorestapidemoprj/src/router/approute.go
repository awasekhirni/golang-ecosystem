package router 

import (
	"github.com/gorilla/mux"
	"../controller"
)

var AppRouter = mux.NewRouter()

func RegisterRoutes(){
	AppRouter.HandleFunc("/books",controller.GetAllBooks).Methods("GET")

	AppRouter.HandleFunc("/books/{id}",controller.GetBookbyId).Methods("GET")

	AppRouter.HandleFunc("/books/add", controller.CreateBook).Methods("POST")

	AppRouter.HandleFunc("/books/edit/{id}", controller.EditBook).Methods("GET")

	AppRouter.HandleFunc("/books/edit/{id}",controller.UpdateBook).Methods("PUT")

	AppRouter.HandleFunc("/books/{id}",controller.RemoveBook).Methods("DELETE")

}


