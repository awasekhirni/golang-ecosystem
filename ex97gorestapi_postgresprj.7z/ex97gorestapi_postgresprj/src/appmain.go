package main

import (
	"fmt"
	"./router"
    "log"
	"net/http"

)

func main() {
	fmt.Println("Go language Postgresql  rest api demo ")
	router.RegisterRoutes()
	httpServer:=http.Server{
		Addr:":9898",
		Handler:router.AppRouter,
	}
	log.Fatal(httpServer.ListenAndServe())


}
