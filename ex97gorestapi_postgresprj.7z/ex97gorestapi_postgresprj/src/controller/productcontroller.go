package controller

import (
	"log"
	"encoding/json"
	"strconv"
	"net/http"
	"github.com/gorilla/mux"
	"../model"
	"../repository"
	"database/sql"
)

var products []model.Product

type Controller struct{}


func logFatal(err error){
	if err!=nil{
		log.Fatal(err)
	}
}


func (c Controller) GetProducts(db *sql.DB) http.HandlerFunc{
	return func(w http.ResponseWriter, r *http.Request){
		var product model.Product 
		products =[]model.Product{}
		productRepo:= repository.ProductRepository{}
		
		products = productRepo.GetProducts(db,product, products)

		//render json 
		json.NewEncoder(w).Encode(products)
	}
}




func (c Controller) GetProductbyId(db *sql.DB) http.HandlerFunc{
	return func(w http.ResponseWriter, r *http.Request){
		var product model.Product 
		params:= mux.Vars(r)

		products=[]model.Product{}
		productRepo:=repository.ProductRepository{}

		id,err:=strconv.Atoi(params["id"])
		logFatal(err)
		
		product=productRepo.GetProductById(db,product,id)
        json.NewEncoder(w).Encode(product)
	}
}


func (c Controller) AddProduct(db *sql.DB) http.HandlerFunc{
	return func(w http.ResponseWriter, r *http.Request){
		var product model.Product
		var productID int 

		json.NewDecoder(r.Body).Decode(&product)

		productRepo:=repository.ProductRepository{}
		productID=productRepo.CreateProduct(db,product)
		
		json.NewEncoder(w).Encode(productID)
	}
}



func (c Controller) UpdateProduct(db *sql.DB) http.HandlerFunc{
	return func(w http.ResponseWriter, r *http.Request){
		var product model.Product 
		json.NewDecoder(r.Body).Decode(&product)

		productRepo:=repository.ProductRepository{}
		rowsUpdated:=productRepo.UpdateProduct(db,product)

		json.NewEncoder(w).Encode(rowsUpdated)

	}
}


func (c Controller) RemoveProduct(db *sql.DB) http.HandlerFunc{
	return func(w http.ResponseWriter,r *http.Request){
		params:=mux.Vars(r)
		productRepo:=repository.ProductRepository{}
		
		id,err:=strconv.Atoi(params["id"])
		logFatal(err)

		rowsDeleted:=productRepo.RemoveProduct(db,id)

		json.NewEncoder(w).Encode(rowsDeleted)
	}
}