package model 

import(
	"fmt"
)

type Product struct{
	ID int `json:"id"`
	Name string  `json:"name"`
	Image string  `json:"image"`
	Description string  `json:"description"`
	Category string  `json:"category"`
	Price int64  `json:"price"`
	Qty float32  `json:"qty"`
	Shipping float32 `json:"shipping"`
	Location string `json:"Location"`
	Color string `json:"color"`
	Link string `json:"link"`
}


//string makes object satisfy the Stringer interface 

func (p Product) String() string{
	return fmt.Sprintf("%d %v %v %v %v %d %f %f %v %v %v",p.ID, p.Name,p.Image,p.Description,p.Category,p.Price, p.Qty, p.Shipping, p.Location, p.Color, p.Link)
}