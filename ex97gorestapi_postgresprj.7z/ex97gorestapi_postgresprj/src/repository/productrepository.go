package repository 

import (
	"../model"
	"database/sql"
	"log"
//	"../config"
)

type ProductRepository struct{}

func logFatal(err error){
	if err!=nil{
		log.Fatal(err)
	}
}

//get all products
func (p ProductRepository) GetProducts(db *sql.DB, product model.Product, products []model.Product) []model.Product{
   // config.OpenDbConn()
	rows, err:=db.Query("SELECT * FROM PRODUCT")
	logFatal(err)
	defer rows.Close()
	
	for rows.Next(){
		err:=rows.Scan(&product.ID,&product.Name, &product.Image, &product.Description, &product.Category, &product.Price, &product.Qty, &product.Shipping, &product.Location,&product.Color,&product.Link)
		logFatal(err)
		
		products=append(products, product)
	}

	return products
}

//get product by id
func (p ProductRepository) GetProductById(db *sql.DB, product model.Product, id int) model.Product{
	//config.OpenDbConn()
	rows:=db.QueryRow("select * from product where id=$1",id)

	err:=rows.Scan(&product.ID,&product.Name, &product.Image, &product.Description, &product.Category, &product.Price, &product.Qty, &product.Shipping, &product.Location,&product.Color,&product.Link)
		logFatal(err)
    defer db.Close()
	return product
}

//Create a new product
func (p ProductRepository) CreateProduct(db *sql.DB, product model.Product) int{
	//config.OpenDbConn()
	err:=db.QueryRow("INSERT into PRODUCT (name,image, description,category,price, qty,shipping,location,color,link) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id;",product.Name, product.Image,product.Description,product.Category,product.Price,product.Qty,product.Shipping, product.Location, product.Color,product.Link).Scan(&product.ID)
	logFatal(err)
    defer db.Close()
	return product.ID
}

//UpdateProduct
func (p ProductRepository) UpdateProduct(db *sql.DB, product model.Product) int64{
	//config.OpenDbConn()
	result,err:=db.Exec("update product set name=$1,image=$2,description=$3,category=$4,price=$5,qty=$6,shipping=$7,location=$8,color=$9,link=$10 where id=$ RETURNING id",&product.Name, &product.Image, &product.Description, &product.Category, &product.Price, &product.Qty,&product.Shipping, &product.Location, &product.Color,&product.Link)
	logFatal(err)
    defer db.Close()
	rowsUpdated,err:=result.RowsAffected()
	logFatal(err)

	return rowsUpdated
}

//RemoveProduct Repository
func (p ProductRepository) RemoveProduct(db *sql.DB, id int) int64 {
	//config.OpenDbConn()
	result,err:=db.Exec("DELETE from Product where id=$1",id)
	logFatal(err)

	rowsDeleted,err:=result.RowsAffected()
	defer db.Close()
	logFatal(err)
	return rowsDeleted 
}