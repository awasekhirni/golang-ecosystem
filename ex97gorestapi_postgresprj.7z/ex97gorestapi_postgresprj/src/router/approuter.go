package router 

import(
	"github.com/gorilla/mux"
	"../controller"
	"database/sql"
	"../config"

)


var AppRouter = mux.NewRouter()
var db *sql.DB


func RegisterRoutes(){
    db=config.OpenDbConn()
	controller:=controller.Controller{}
	AppRouter.HandleFunc("/api/products",controller.GetProducts(db)).Methods("GET")
	AppRouter.HandleFunc("/api/products/{id}",controller.GetProductbyId(db)).Methods("GET")
	AppRouter.HandleFunc("/api/products/add",controller.AddProduct(db)).Methods("POST")
	AppRouter.HandleFunc("/api/products/update/{id}",controller.UpdateProduct(db)).Methods("PUT")
	AppRouter.HandleFunc("/api/products/remove/{id}",controller.RemoveProduct(db)).Methods("DELETE")

}

