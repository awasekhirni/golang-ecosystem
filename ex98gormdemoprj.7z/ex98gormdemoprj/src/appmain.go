package main
//Copyright 2017-18 Syed Awase Khirni awasekhirni@gmail.com www.territorialprescience.com www.sycliq.com
import (
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
	"./model"
	"fmt"
)

func main() {

	//open connection to the postgresql db
	db, err := gorm.Open("postgres", "user=postgres password=dbp@ssw0rd dbname=ex98gormdemoprj sslmode=disable")

	if err != nil {
		panic(err.Error())
	}

	defer db.Close()

	//do not use the drop in production
	db.DropTable(&model.Product{})

	//call to create a new table using the product type
	db.CreateTable(&model.Product{})

	ebayProduct:=model.Product{
            Name: "ATH M50X Headphone",
            Image: "http://i.ebayimg.com/00/s/MTAwMFgxMDAw/z/YFYAAOSwPhdVOjdQ/$_12.JPG",
            Description: "ATH-M50xDG Limited Edition Professional Studio Monitor Headphones - Dark Green; Pure. Professional. Performance. As the most critically acclaimed model in the M-Series line, the ATH-M50 is praised by top audio engineers and pro audio reviewers year after year.",
            Category: "Electronics",
            Price: 8631,
            Quantity: 3.0,
            Shipping: 0,
            Location: "Mumbai",
            Color: "#6B5419",
            Link: "http://www.ebay.in/sch/i.html?_nkw=m50x&_sop=16",
	}

	//insert records into the table 
	db.Create(&ebayProduct)
	fmt.Println("Successfully inserted a record into postgresql database!")
	
	var amazonProducts []model.Product=[]model.Product{
		model.Product{
            Name: "Sony PS4 500GB",
            Image: "http://i.ebayimg.com/00/s/NDcyWDYxOA==/z/wM4AAOSwZjJVAEUf/$_12.JPG",
            Description: "The PlayStation4 system opens the door to an incredible journey through immersive new gaming worlds and a deeply connected gaming community. PS4 puts gamers first with an astounding launch lineup and over 180 games in development. Play amazing top-tier blockbusters and innovative indie hits on PS4.",
            Category: "Electronics",
            Price: 34463,
            Quantity: 7,
            Shipping: 0,
            Location: "Delhi",
            Color: "#302E29",
            Link: "http://www.ebay.in/sch/i.html?_nkw=ps4&_sop=16",
        },
        model.Product{
            Name: "Handy Chopper (Slicer)",
            Image: "http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/bPAAAOSwBahU7V4G/$_12.JPG",
            Description: "Nicer Dicer With Plus you have a kitchen helper, who will shorten the cooking time from start of preparation to the serving of the meal tremendously.",
            Category: "Household",
            Price: 549,
            Quantity: 10,
            Shipping: 0,
            Location: "Chennai",
            Color: "#B6E314",
            Link: "http://www.ebay.in/sch/i.html?_nkw=NICER+DICER+PLUS+CHOPPER&_sop=16",
        },
        model.Product{
            Name: "OnePlus Two 64GB",
            Image: "http://i.ebayimg.com/00/s/Mzc4WDcyMA==/z/aUoAAOSwyQtV4-Kg/$_12.JPG",
            Description: "With the OnePlus 2, we have something bold to say. We believe that great products come from great ideas, not multi-million dollar marketing campaigns. We believe \"that’s just the way things are\" is almost always the wrong answer. Most of all, we believe that great things should be shared.",
            Category: "Electronics",
            Price: 34999,
            Quantity: 1,
            Shipping: 100,
            Location: "Punjab",
            Color: "#E35A4B",
            Link: "http://www.ebay.in/sch/i.html?_nkw=OnePlus+Two&_sop=16",
        },
	}

	for _,product:=range amazonProducts{
		db.Create(&product)

	}

	p:=model.Product{}
	//fetching the first record
	//db.First(&p)
	//fmt.Println(p)

	//fetching the last record 
	db.Last(&p)
	fmt.Println(p)



}
