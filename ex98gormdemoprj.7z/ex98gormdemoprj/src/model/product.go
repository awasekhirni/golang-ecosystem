package model

import ()

type Product struct {
	ID int 
	Name string 
	Image string
	Description string 
	Category string 
	Price int 
	Quantity float64
	Shipping float64
	Location string 
	Color string 
	Link string 
}
