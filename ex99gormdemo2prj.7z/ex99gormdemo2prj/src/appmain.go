package main

//Copyright 2017-18 Syed Awase Khirni awasekhirni@gmail.com 
//www.territorialprescience.com www.sycliq.com

import (
	"fmt"
	"./model"
	"github.com/jinzhu/gorm"
	_ "github.com/lib/pq"
)

func main(){
	//one to one association demo
//database connection parameters
fmt.Println("One to One Association Demo using Gorm")
	db,err:=gorm.Open("postgres","user=postgres password=dbp@ssw0rd dbname=ex99gormdemodb sslmode=disable")
	if err !=nil{
		panic(err.Error())
	}

	//close the database connection 
	defer db.Close()

	//do not use the drop in production 
	db.DropTable(&model.User{})
	db.DropTable(&model.Calendar{})
	db.DropTable(&model.Appointment{})

	//call to create a new table 
	db.CreateTable(&model.User{})
	db.CreateTable(&model.Calendar{})
	db.CreateTable(&model.Appointment{})
 
	
	//inserting records into the tables 
	db.Debug().Save(&model.User{
		UserName: "SyedAwase",
		FirstName: "Awase Khirni",
		LastName:"Syed",
		DateofBirth:"03/Nov/19XX",
		Gender:"true",
		Calendar:model.Calendar{
			Name:"ReleaseCalendar",
			Year:2017,
			Appointments:[]model.Appointment{
				{Subject:"Scrum Meeting"},
				{Subject:"Ops Review"},
			},
		},
	})

	db.Debug().Model(&model.Calendar{}).
	       AddForeignKey("user_id","users(id)","CASCADE","CASCADE")


	u:=model.User{}
	c:=model.Calendar{}
	db.First(&u).Related(&c,"calendar")
	fmt.Println(u)
	fmt.Println(c)

}