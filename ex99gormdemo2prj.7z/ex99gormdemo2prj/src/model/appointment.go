package model 

import (
	"time"
	"github.com/jinzhu/gorm"
)

type Appointment struct{
	gorm.Model 
	Subject string 
	Description string 
	StartTime time.Time 
	Length uint
	CalendarID uint 
}