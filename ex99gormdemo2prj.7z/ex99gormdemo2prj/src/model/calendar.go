package model 

import (
	"github.com/jinzhu/gorm"
)

type Calendar struct{
	gorm.Model 
	Name string 
	Year int  
	UserID uint
	Appointments []Appointment
}