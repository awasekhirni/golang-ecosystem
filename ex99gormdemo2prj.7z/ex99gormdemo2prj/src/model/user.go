package model 

import (
	"github.com/jinzhu/gorm"
)

type User struct{
	gorm.Model 
	UserName string `sql:"type:VARCHAR(50) not null"`
	FirstName string  `sql:"type:TEXT not null"`
	LastName string  `sql:"type:TEXT not null"`
	DateofBirth string `sql:"type:TEXT  not null"`
	Gender string `sql:"type:Bool not null"`
    Calendar Calendar `gorm:one2one`

}
