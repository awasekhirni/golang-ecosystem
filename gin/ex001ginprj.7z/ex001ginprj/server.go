package main 

import (
	"github.com/gin-gonic/gin"

)

func main(){

	//create server 
	server := gin.Default()

	//controller action methods for the routes
	server.GET("/home",func(ctx *gin.Context){
		ctx.JSON(200, gin.H{
			"message":"Welcome to Gin-Golang Framework! You dont need to get a drink to get the kick off it!",
		})
	})

	//running the server and binding it to the port to render the path 
	server.Run(":9393")
}