package controllers

import (
	"github.com/gin-gonic/gin"
	"ex002ginprj/models"
	"ex002ginprj/service"
	// "fmt"
	//"encoding/json"

)

//interface definition
type EmployeeController interface{
	GetAll() []models.Employee
    Save(ctx *gin.Context) models.Employee
}
//controller type definition
type controller struct{
    service service.EmployeeService
}
// new instance controller
func New(service service.EmployeeService) EmployeeController{
	return &controller{
		service: service,
	}
}


func (c *controller) GetAll() []models.Employee{
 return c.service.GetAll()
}

func (c *controller) Save(ctx *gin.Context) models.Employee{
	var emp models.Employee  
	ctx.Writer.Header().Del("Content-Type")

	ctx.Writer.Header().Set("Content-Type", "application/json") 
	ctx.ShouldBindJSON(&emp)
	//fmt.Println(&jsonData)
	c.service.Save(emp)
	return emp
}

// func writeContentType(w http.ResponseWriter, value []string) {
//     header := w.Header()
//     log.Println(header.Get("Content-Type")) // <=========== Nothing happen
//     if val := header["Content-Type"]; len(val) == 0 {
//         header["Content-Type"] = value
//     }
// }