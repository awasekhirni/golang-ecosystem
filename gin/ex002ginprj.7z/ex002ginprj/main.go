package main 

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"ex002ginprj/controllers"
	"ex002ginprj/service"

)

var(
	empService service.EmployeeService = service.New()
	empCtrl controllers.EmployeeController = controllers.New(empService)
)

func main(){

	fmt.Println("Ex002-Gin-Golang-REST API basic demo!") 
	//create server instance 
	 server := gin.Default()


//http-verb get
	 server.GET("/api/employees/all",func(ctx *gin.Context){
		 ctx.JSON(200, empCtrl.GetAll())
	 })

//http-verb post 
    server.POST("/api/employees/add",func(ctx *gin.Context){
		ctx.JSON(200,empCtrl.Save(ctx))
	})



	 server.Run(":9393")

}