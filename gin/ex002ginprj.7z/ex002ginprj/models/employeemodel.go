package models

import (

)

type Employee struct{
	
	Name string `json:"name"`
	Department string `json:"department"`
	Designation string `json:"designation"`
	Salary string `json:"salary"`
	IsFTE string `json:"isfte"`
}