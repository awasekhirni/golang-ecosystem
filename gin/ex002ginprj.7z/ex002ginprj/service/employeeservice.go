package service 

import (
   "ex002ginprj/models"
)

type EmployeeService interface{
	Save(models.Employee) models.Employee
	GetAll() []models.Employee
}

type employeeService struct{
	employees []models.Employee
}

func New() EmployeeService{
	return &employeeService{
		employees:[]models.Employee{},
	}
}

//service methods implementation 

func (empsvc *employeeService) Save(employee models.Employee) models.Employee{
   empsvc.employees = append(empsvc.employees,employee)
   return employee
}

func (empsvc *employeeService) GetAll() []models.Employee{
	return empsvc.employees
}
