package main 

import (
	"fmt"
    "ex003ginprj/middleware"
    "ex003ginprj/service"
    "ex003ginprj/controller"
    gindump "github.com/tpkeeper/gin-dump"
    "os"
    "io"
    "github.com/gin-gonic/gin"
)


var (
    customerService service.CustomerService = service.NewCustomer()
    customerController controller.CustomerController= controller.NewCustomer(customerService)

    contactService service.ContactService = service.NewContact()
    contactController controller.ContactController = controller.NewContact(contactService)
)

//writing logger to an external file 
func setupLogOutput(){
    f,_:=os.Create("log/ex003ginprj.log")
    gin.DefaultWriter =io.MultiWriter(f,os.Stdout)

}

func main(){
   fmt.Println("Ex003- CRUD Application with GIN and GORM")
   //call the external logwriter function
   setupLogOutput()
   //create a new instance of the server
   server := gin.New()
   //add the middleware 
   server.Use(gin.Recovery(),middleware.Logger(),middleware.Authorize(),gindump.Dump())
   

   //customer-routes 
   server.GET("/api/customers/all", func(ctx *gin.Context){
       ctx.JSON(200, customerController.GetAll())
   })

   server.POST("/api/customers/add",func(ctx *gin.Context){
       ctx.JSON(200, customerController.Save(ctx))
   })
   //contact-routes 
    server.GET("/api/contacts/all", func(ctx *gin.Context){
       ctx.JSON(200, contactController.GetAll())
   })

   server.POST("/api/contacts/add",func(ctx *gin.Context){
       ctx.JSON(200, contactController.Save(ctx))
   })

   server.Run(":9393")





}