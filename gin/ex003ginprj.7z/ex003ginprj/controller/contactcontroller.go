package controller

import (
	"github.com/gin-gonic/gin"
	"ex003ginprj/models"
	"ex003ginprj/service"
)


//interface definition 
type ContactController interface{
	GetAll() []models.Contact 
	Save(ctx *gin.Context) models.Contact
}

//controller type definition 
type contactCtrl struct{
	service service.ContactService
}

//new instance controller 
func NewContact(service service.ContactService) ContactController{
	return &contactCtrl{
		service:service,
	}
}


func (c *contactCtrl) GetAll() []models.Contact{
	return c.service.GetAll()
}


func (c *contactCtrl) Save(ctx *gin.Context) models.Contact{
	var contact models.Contact 
	// ctx.Writer.Header().Del("Content-Type")
	// ctx.Writer.Header.Set("Content-Type","application/json")
	ctx.BindJSON(&contact)
	c.service.Save(contact)
	return contact 
}