package controller

import (
	"github.com/gin-gonic/gin"
	"ex003ginprj/models"
	"ex003ginprj/service"
)

//interface definition 
type CustomerController interface{
	GetAll() []models.Customer 
	Save(ctx *gin.Context) models.Customer
}


//controller type definition
type customerCtrl struct{
	service service.CustomerService
}

//new instance controller 
func NewCustomer(service service.CustomerService) CustomerController{
	return &customerCtrl{
		service:service,
	}
}

func (c *customerCtrl) GetAll() []models.Customer{
	return c.service.GetAll()
}


func (c *customerCtrl) Save(ctx *gin.Context) models.Customer{
	var customer models.Customer 
	// ctx.Writer.Header().Del("Content-Type")
	// ctx.Writer.Header.Set("Content-Type","application/json")
	ctx.BindJSON(&customer)
	c.service.Save(customer)
	return customer
}

