package models 

import (

)

type Contact struct{
	ContactId int64 `json:"contactid" binding:"required"`
	IsdCode int16  `json:"" binding:"required"`
	Mobile uint64 `json:"" binding:"required"`
	Email string `json:"email" binding:"required,email"`
	Customer string `json:"customer" binding:"required"`
}