package models 

import (

)

type Customer struct{
	CustomerId int64 `json:"customerid" binding:"required"`
	CustomerName string `json:"customername" binding:"required"`
	Age int8 `json:"age" binding:"gte=1,lte=125"`
	Gender string `json:"gender" binding:required`
}