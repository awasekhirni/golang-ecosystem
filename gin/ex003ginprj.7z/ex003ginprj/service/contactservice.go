package service 

import (
	"ex003ginprj/models"
)

type ContactService interface{
	Save(models.Contact) models.Contact 
	GetAll() []models.Contact
}

type contactService struct{
	contacts []models.Contact 
}

func NewContact() ContactService{
	return &contactService{
		contacts:[]models.Contact{},
	}
}

//service methods implementation 

func (cntsvc *contactService) Save(contact models.Contact) models.Contact{
	cntsvc.contacts = append(cntsvc.contacts, contact)
	return contact 
}


func (cntsvc *contactService) GetAll() []models.Contact{
	return cntsvc.contacts
}