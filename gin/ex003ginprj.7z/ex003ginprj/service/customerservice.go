package service 

import (
	"ex003ginprj/models"
)

type CustomerService interface{
	Save(models.Customer) models.Customer 
	GetAll() []models.Customer 
	
}

type customerService struct{
	customers []models.Customer 
}

func NewCustomer() CustomerService{
	return &customerService{
		customers: []models.Customer{},
	}
}

//service methods implementation 
func (cstsvc *customerService) Save(customer models.Customer) models.Customer{
	cstsvc.customers = append(cstsvc.customers, customer)
	return customer 
}


func (cstsvc *customerService) GetAll() []models.Customer{
	return cstsvc.customers
}