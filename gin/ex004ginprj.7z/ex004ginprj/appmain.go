package main 

import (
	"fmt"
	// "github.com/gin-gonic/gin"
	// // "net/http"
	// "os"
	"ex004ginprj/routes"
	
)



func main(){

	fmt.Println("Demo4- gin-gonic-gorm -crud application!- Syed Awase Khirni")

	
	routes.ConfigureRoutePath()

	

}