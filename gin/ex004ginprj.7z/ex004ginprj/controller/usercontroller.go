package controller

import (
	"strconv"
	"net/http"
	"ex004ginprj/service"
	"github.com/gin-gonic/gin"
	"ex004ginprj/models"
	"gopkg.in/go-playground/validator.v9"
)

type UserController interface{
	GetAll() []models.User 
	Save(ctx *gin.Context) error
	Update(ctx *gin.Context) error 
	Delete(ctx *gin.Context) error 
	ShowAll(ctx *gin.Context)
}


type usrCtrl struct {
	service service.UserService
}

var validate *validator.Validate

func New(service service.UserService) UserController{
	validate = validator.New()
	return &usrCtrl{
		service: service,
	}
}


func (c *usrCtrl) GetAll() []models.User{
	return c.service.FindAll()
}

func (c *usrCtrl) Save(ctx *gin.Context) error{
	var user models.User
	err := ctx.ShouldBindJSON(&user)
	if err != nil{
		return err
	}
	err = validate.Struct(user)
	if err != nil{
		return err
	}
	c.service.Save(user)
	return nil
}


func (c *usrCtrl) Update(ctx *gin.Context) error{
	var user models.User 
	err:= ctx.ShouldBindJSON(&user)
	if err !=nil{
		return err
	}
	id,err := strconv.ParseUint(ctx.Param("id"),0,0)
	if err !=nil{
		return err
	}
	user.Id = id 
	err = validate.Struct(user)
	if err !=nil{
		return err
	}
	c.service.Update(user)
	return nil
}


func (c *usrCtrl) Delete(ctx *gin.Context) error{
	var user models.User 
	id, err := strconv.ParseUint(ctx.Param("id"),0,0)
	if err !=nil{
		return err
	}
	user.Id = id 
	c.service.Delete(user)
	return nil 
}

func (c *usrCtrl) ShowAll(ctx *gin.Context){
	users := c.service.FindAll()
	data:= gin.H{
		"title":"Users List Page",
		"users":users,
	}
	ctx.HTML(http.StatusOK,"index.html",data)
}
