package models

import (
	//"time"
	//"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
)

type User struct{
	
	Id uint64 `gorm:"primary_key" json:"id"`
	Name string `gorm:"type:varchar(255);NOT NULL" json:"name" binding:"required"`
	Email string `gorm:"type:varchar(255);NOT NULL json:"email" binding:"required email"`
	Phone string `gorm:"type:varchar(25);NOT NULL; UNIQUE;UNIQUE_INDEX" json:"phone" binding:"required"`
	Address string `gorm:"type:text" json:"address" binding:"required"`
	//CreatedAt time.Time `json:"-" gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`
	//UpdatedAt time.Time `json:"-" gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`
}

type Users []User