package repository

import (
	"ex004ginprj/models"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
)


type UserRepository interface{
	Save(user models.User)
	Update(user models.User)
	Delete(user models.User)
	FindAll() []models.User 
	CloseDB()
}

type dbConnection struct{
	connection *gorm.DB
}

func NewUserRepository() UserRepository{
	db,err:=gorm.Open("sqlite3","dev_ex004ginprj")
	if err !=nil{
		panic("Failed to connect to SQLite database")
	}
	db.AutoMigrate(&models.User{})
	//db.AutoMigrate(&models.User{},&models.Product{})
	return &dbConnection{
		connection:db,
	}
}

//close database connection 
func (db *dbConnection) CloseDB(){
	err := db.connection.Close()
	if err != nil{
		panic("Failed to close database!!")
	}
}

func (db *dbConnection) Save(user models.User){
	db.connection.Create(&user)
}

func (db *dbConnection) Update(user models.User){
	db.connection.Save(&user)
}

func (db *dbConnection) Delete(user models.User){
	db.connection.Delete(&user)
}


func (db *dbConnection) FindAll() []models.User{
	var users []models.User
	db.connection.Set("gorm:auto_preload",true).Find(&users)
	return users
}


