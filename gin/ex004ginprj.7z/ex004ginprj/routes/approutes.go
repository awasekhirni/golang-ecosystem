package routes 

import (
  "net/http"
  "github.com/gin-gonic/gin"
    "ex004ginprj/controller"
	"ex004ginprj/repository"
	"ex004ginprj/service"
	gindump "github.com/tpkeeper/gin-dump"
	"ex004ginprj/middleware"
	"os"
	"io"

)

var(
	userRepository repository.UserRepository = repository.NewUserRepository()
	
	userService service.UserService = service.New(userRepository)

	userCtrl controller.UserController = controller.New(userService)

	
)



func setupLogOutput(){
    f,_:=os.Create("log/ex004ginprj.log")
    gin.DefaultWriter =io.MultiWriter(f,os.Stdout)

}

func ConfigureRoutePath() *gin.Engine{
	setupLogOutput()
	route :=gin.New()

	route.Use(gin.Recovery())
	route.Use(middleware.Logger())
	route.Use(middleware.Authorize())

	route.Use(gindump.Dump())

	v1:=route.Group("/api/v1")

	v1.GET("/users",func(ctx *gin.Context){
		ctx.JSON(200,userCtrl.GetAll())
	})

	v1.POST("/users/add", func(ctx *gin.Context){
			err := userCtrl.Save(ctx)
			if err != nil {
				ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			} else {
				ctx.JSON(http.StatusOK, gin.H{"message": "Success!"})
			}
		})


	route.Run(":9393")

	


	return route

	
}

