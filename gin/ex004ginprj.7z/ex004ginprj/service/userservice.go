package service 

import (
	"ex004ginprj/repository"
	"ex004ginprj/models"
)

type UserService interface{
	Save(models.User) error
	Update(models.User) error 
	Delete(models.User) error 
	FindAll() []models.User 
}

type userService struct{
	userrepo repository.UserRepository
}


func New(userRepository repository.UserRepository) UserService{
	return &userService{
		userrepo: userRepository,
	}
}


func (service *userService) Save(user models.User) error{
	service.userrepo.Save(user)
	return nil 
}


func (service *userService) Update(user models.User) error{
	service.userrepo.Update(user)
	return nil
}

func (service *userService) Delete(user models.User) error{
	service.userrepo.Delete(user)
	return nil 
}

func (service *userService) FindAll() []models.User{
	return service.userrepo.FindAll()
}
