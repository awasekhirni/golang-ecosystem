package main 

import (
	"github.com/jinzhu/gorm"
	"github.com/google/wire"
	"ex004ginprj/repository"
	"ex004ginprj/service"
	"ex004ginprj/controller"
)

func initApi(db *gorm.DB) controller.UserController{
	wire.Build(repository.NewUserRepository, service.NewUserService,controller.UserController)
    return controller.UserController{}
}