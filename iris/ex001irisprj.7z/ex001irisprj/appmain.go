package main

import (
	"fmt"

	"github.com/kataras/iris/v12"
	"github.com/kataras/iris/v12/middleware/logger"
	"github.com/kataras/iris/v12/middleware/recover"
)

func main() {
	fmt.Println("Iris Web Framework - Golang - Syed Awase Khirni - Example 1")

	//initializing the iris application
	appiris := iris.New()

	//setting to debug mode
	appiris.Logger().SetLevel("debug")

	//adding middleware // similar to gin
	appiris.Use(recover.New())
	appiris.Use(logger.New())

	appiris.Get("/greet", func(ctx iris.Context) {
		ctx.HTML("<h1>Welcome to AlphaFactory Codeplay Session - SyedAwaseKhirni</h1> ")
	})

	appiris.Get("/greeter", func(ctx iris.Context) {
		ctx.Text("Welcome to AlphaFactory Codeplaysessions- Rendering in Text format")

	})

	appiris.Get("/greatest", func(ctx iris.Context) {
		ctx.WriteString("Welcome to AlphaFactory Codeplaysession- String Rendering!")
	})

	//running the application //similar to gin
	//similar to mux framework http.listenandserver()
	appiris.Run(iris.Addr(":9393"))
}
