package main 

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"github.com/kataras/iris/v12/middleware/logger"
	"github.com/kataras/iris/v12/middleware/recover"
)

func main(){
	fmt.Println("Iris Web Framework Golang - Use Templates with Bootstrap- Example 2 - Syed Awase Khirni")

	//initializing the iris application 
	app := iris.New()

	//setting logger to debug mode 
	app.Logger().SetLevel("debug")

	//adding middleware similar to gin 
	app.Use(recover.New(), logger.New())

	// rendering external html files view/templates
	app.Get("/landingpage",func(ctx iris.Context){
		ctx.ServeFile("views/bs_landingpage.html",false)
	})

	app.Get("/gray",func(ctx iris.Context){
		ctx.ServeFile("views/bs_gray.html",false)
	})

	app.Get("/newage",func(ctx iris.Context){
       ctx.ServeFile("views/bs_newage.html",false)
	})

	app.Get("/stylish",func(ctx iris.Context){
      ctx.ServeFile("views/bs_style.html",false)
	})

	app.Get("/comesoon",func(ctx iris.Context){
      ctx.ServeFile("views/bs_comesoon.html",false)
	})


	//listen and serving ports
	app.Run(iris.Addr("localhost:9393"))



}