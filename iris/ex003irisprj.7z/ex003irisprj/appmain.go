package main 

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"github.com/kataras/iris/v12/middleware/logger"
	"github.com/kataras/iris/v12/middleware/recover"
)

func main(){
	fmt.Println("Iris Web Framework Golang - Using template with bootstrap - Example 3- Syed Awase Khirni")
   // approach 2 

   //initializing the iris application 
   app:=iris.New()

   //setting logger to the debug mode 
   app.Logger().SetLevel("debug")
   //adding middleware similar to gin 
   app.Use(recover.New(), logger.New())

   //rendering templates 
 //iris offers support for 6 template parsers out of the box  
 //https://kataras.gitbooks.io/iris/content/view.html 
   app.RegisterView(iris.HTML("./views",".html"))
//2-    app.RegisterView(iris.Handlebars("./views",".hbs"))
//3-    app.RegisterView(iris.Pug("./views",".pug"))
//4- app.RegisterView(iris.Django("",""))
//5- app.RegisterView(iris.Amber("",""))
//6- app.RegisterView(iris.Jet("",""))

// rendering external html files view/templates
	app.Get("/landingpage",func(ctx iris.Context){
		ctx.ViewData("pageTitle","SycliQ Landing")
		ctx.View("bs_landingpage.html")
	})

	app.Get("/gray",func(ctx iris.Context){
		ctx.ViewData("pageMessage","GrayHound")
		ctx.View("bs_gray.html")
	})

	app.Get("/newage",func(ctx iris.Context){
       ctx.ViewData("pageMessage","NewAge Aliens")
		ctx.View("bs_newage.html")
	})

	app.Get("/stylish",func(ctx iris.Context){
      ctx.ViewData("pageMessage","Style bhai! Golmaal returns")
		ctx.View("bs_style.html")
	})

	app.Get("/comesoon",func(ctx iris.Context){
      ctx.ViewData("pageMessage","Munna bhai mbbs")
		ctx.View("bs_comesoon.html")
	})

  //listen and serve
    app.Run(iris.Addr("localhost:9393"))

}