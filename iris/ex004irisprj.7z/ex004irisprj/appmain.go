package main 

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"github.com/kataras/iris/v12/middleware/logger"
	"github.com/kataras/iris/v12/middleware/recover"
)

func main(){
	fmt.Println("Iris Web Framework Golang - Using template with bootstrap FORM - Example 4- Syed Awase Khirni")
   // approach 2 

   //initializing the iris application 
   app:=iris.New()
   //setting logger to the debug mode 
   app.Logger().SetLevel("debug")
   //adding middleware similar to gin 
   app.Use(recover.New(),logger.New())
   app.RegisterView(iris.HTML("./views",".html"))

  app.Get("/form",func(ctx iris.Context){
      ctx.View("form.html")
  })

  app.Post("/form/add",func(ctx iris.Context){
	articleTitle:=ctx.PostValue("articleTitle")
	articleCategory:=ctx.PostValue("articleCategory")
	articleDescription:=ctx.PostValue("articleDescription")
	ctx.ViewData("ArticleTitle",articleTitle)
	ctx.ViewData("ArticleCategory",articleCategory)
	ctx.ViewData("ArticleDescription",articleDescription)
	ctx.View("form.html")
	
	})


  //listen and serve
  app.Run(iris.Addr("localhost:9393"))





}