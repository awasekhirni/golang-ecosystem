package main

import (
	"fmt"
	"github.com/kataras/iris"
	"github.com/kataras/iris/mvc"
	"ex005irisprj/data"
	"ex005irisprj/repository"	
	"ex005irisprj/service"
	"ex005irisprj/controller"
	"ex005irisprj/middleware"
)


func main(){
	fmt.Println("Ex005-Movie CRUD with IRIS Framework-Syed Awase Khirni")

	app:=iris.New()
	app.Logger().SetLevel("debug")

	app.RegisterView(iris.HTML("./views", ".html"))
	mvc.Configure(app.Party("/movies"), movieApp)
	app.Run(
            
			iris.Addr("localhost:9393"),
			//iris.WithoutVersionChecker,
            iris.WithoutServerError(iris.ErrServerClosed),
            iris.WithOptimizations,
        )
}

//movieApp 
func movieApp(app *mvc.Application) {
   
        app.Router.Use(middleware.BasicAuth)
        repo := repository.NewMovieRepository(data.Movies)
        movieService := service.NewMovieService(repo)
        app.Register(movieService)
        
        app.Handle(new(controller.MovieController))
    }
