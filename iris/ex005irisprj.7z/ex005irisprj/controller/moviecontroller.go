package controller 

import (
	"errors"
	"ex005irisprj/models"
	"ex005irisprj/service"
	"github.com/kataras/iris"
)


type MovieController struct{
	Service service.MovieService
}

func (c *MovieController) Get() (results []models.Movie) {
        return c.Service.GetAll()
	}
	

func (c *MovieController) GetBy(id int64) (movie models.Movie, found bool) {
        return c.Service.GetByID(id) // it will throw 404 if not found.
	}
	
	func (c *MovieController) PutBy(ctx iris.Context, id int64) (models.Movie, error) {
        // get the request data for poster and genre
        file, info, err := ctx.FormFile("poster")
        if err != nil {
            return models.Movie{}, errors.New("failed due form file 'poster' missing")
        }
       
        file.Close()
       
        poster := info.Filename
        genre := ctx.FormValue("genre")
        return c.Service.UpdatePosterAndGenreByID(id, poster, genre)
	}
	
	func (c *MovieController) DeleteBy(id int64) interface{} {
        wasDel := c.Service.DeleteByID(id)
        if wasDel {
            
            return iris.Map{"deleted": id}
        }
   
        return iris.StatusBadRequest
    }