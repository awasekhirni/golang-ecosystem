package repository 

import (
	"errors"
	"sync"
	"ex005irisprj/models"
)

//Query
type Query func(models.Movie) bool 

type MovieRepository interface{
	Exec(query Query, action Query, limit int, mode int)(ok bool)
	Select(query Query)(movie models.Movie,found bool)
	SelectMany(query Query, limit int)(results []models.Movie)
	InsertOrUpdate(movie models.Movie)(updatedMovie models.Movie,err error)
	Delete(query Query, limit int)(deleted bool)

}


func NewMovieRepository(source map[int64]models.Movie) MovieRepository{
	return &movieMemoryRepository{
		source:source,
	}
}

type movieMemoryRepository struct{
	source map[int64]models.Movie
	mu sync.RWMutex
}

const(
	//readonly mode will readlock the data 
	ReadOnlyMode =iota 
	//readwrite mode will lock(read/write)
	ReadWriteMode
)


//Exec 
func (r *movieMemoryRepository) Exec(query Query, action Query, actionLimit int, mode int) (ok bool) {
        loops := 0
        if mode == ReadOnlyMode {
            r.mu.RLock()
            defer r.mu.RUnlock()
        } else {
            r.mu.Lock()
            defer r.mu.Unlock()
        }
        for _, movie := range r.source {
            ok = query(movie)
            if ok {
                if action(movie) {
                    loops++
                    if actionLimit >= loops {
                        break // break
                    }
                }
            }
        }
        return
	}
	
//Select where 
	 func (r *movieMemoryRepository) Select(query Query) (movie models.Movie, found bool) {
        found = r.Exec(query, func(m models.Movie) bool {
            movie = m
            return true
        }, 1, ReadOnlyMode)

        if !found {
            movie = models.Movie{}
        }
        return
	}
	
//SelectAll
	func (r *movieMemoryRepository) SelectMany(query Query, limit int) (results []models.Movie) {
        r.Exec(query, func(m models.Movie) bool {
            results = append(results, m)
            return true
        }, limit, ReadOnlyMode)
        return
    }

//Insert or Update
	func (r *movieMemoryRepository) InsertOrUpdate(movie models.Movie) (models.Movie, error) {
        id := movie.ID
        if id == 0 { // Create new action
            var lastID int64
            
            r.mu.RLock()
            for _, item := range r.source {
                if item.ID > lastID {
                    lastID = item.ID
                }
            }
            r.mu.RUnlock()
            id = lastID + 1
            movie.ID = id
            // map-specific thing
            r.mu.Lock()
            r.source[id] = movie
            r.mu.Unlock()

            return movie, nil
		}
		current, exists := r.Select(func(m models.Movie) bool {
            return m.ID == id
        })
        if !exists { 
            return models.Movie{}, errors.New("failed to update a nonexistent movie")
        }
        if movie.Poster != "" {
            current.Poster = movie.Poster
        }
        if movie.Genre != "" {
            current.Genre = movie.Genre
        }
        // map-specific thing
        r.mu.Lock()
        r.source[id] = current
        r.mu.Unlock()
        return movie, nil
	}
	
//delete
    func (r *movieMemoryRepository) Delete(query Query, limit int) bool {
        return r.Exec(query, func(m models.Movie) bool {
            delete(r.source, m.ID)
            return true
        }, limit, ReadWriteMode)
    }