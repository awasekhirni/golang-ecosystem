package service 

import (
	"ex005irisprj/models"
	"ex005irisprj/repository"
)


type MovieService interface{
	GetAll() []models.Movie
	GetByID(id int64)(models.Movie,bool)
	DeleteByID(id int64) bool 
	UpdatePosterAndGenreByID(id int64, poster string, genre string) (models.Movie, error)
}

func NewMovieService(repo repository.MovieRepository) MovieService{
	return &movieService{
		repo:repo,
	}
}


type movieService struct{
	repo repository.MovieRepository
}

func (s *movieService) GetAll() []models.Movie{
	return s.repo.SelectMany(func(_ models.Movie) bool{
		return true
	}, -1)
}


func (s *movieService) GetByID(id int64)(models.Movie, bool){
	return s.repo.Select(func(m models.Movie) bool{
		return m.ID==id 
	})
}


 func (s *movieService) UpdatePosterAndGenreByID(id int64, poster string, genre string) (models.Movie, error) {
        // update the movie and return it.
        return s.repo.InsertOrUpdate(models.Movie{
            ID:     id,
            Poster: poster,
            Genre:  genre,
        })
	}

func (s *movieService) DeleteByID(id int64) bool {
        return s.repo.Delete(func(m models.Movie) bool {
            return m.ID == id
        }, 1)
    }

	
